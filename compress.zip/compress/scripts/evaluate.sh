dataset_name="rockyou"
test_dataset="./dataset/${dataset_name}-cleaned-Test.txt"
# output_path should change the generate num by the generate_num in generate.sh 
# output_pathはgenerate.shのgenerate_numで生成数を変更する。
output_path="./generate/1000000/"
ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー

# 1. evaluate generated passwords in the normal method
# 1. 生成されたパスワードを通常の方法で評価する
python evaluate.py --test_file="$test_dataset" --gen_path="$gen_path" --isNormal
python evaluate.py --test_file=./dataset/rockyou-cleaned-Test.txt --gen_path=./generate/10000 --isNormal

ヘルプ
usage: evaluate.py [-h] --test_file TEST_FILE --gen_path GEN_PATH [--isNormal]
evaluate.py: error: the following arguments are required: --test_file, --gen_path

"--test_file"　"file of test set"　テストセットのファイル
"--isNormal"　"whether the generated password is in normal method"　生成されたパスワードが通常の方法であるかどうか

ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー

# 2. evaluate generated passwords in the DC-GEN method
# 2. DC-GEN方式で生成されたパスワードの評価
python evaluate.py --test_file="$test_dataset" --gen_path="$gen_path"

ヘルプ
usage: evaluate.py [-h] --test_file TEST_FILE --gen_path GEN_PATH [--isNormal]
evaluate.py: error: the following arguments are required: --test_file, --gen_path