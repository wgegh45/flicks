dataset_name="rockyou"
original_dataset="./dataset/${dataset_name}.txt"
cleaned_dataset="./dataset/${dataset_name}-cleaned.txt"
training_dataset="./dataset/${dataset_name}-cleaned-Train.txt"
test_dataset="./dataset/${dataset_name}-cleaned-Test.txt"
ready4train_dataset="./dataset/${dataset_name}-cleaned-Train-ready.txt"

ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー

# 1. clean dataset　　rockyou.txtからrockyou-cleaned.txt(4-12以外の長さとASCII以外の文字を含むパスワードを除外)を作る
python clean_dataset.py --dataset_path=$original_dataset         --output_path=$cleaned_dataset
python clean_dataset.py  --dataset_path=./dataset/rockyou.txt  --output_path=./dataset/rockyou-cleaned.txt

ヘルプ
python clean_dataset.py  -h
usage: clean_dataset.py [-h] --dataset_path DATASET_PATH --output_path OUTPUT_PATH
options:
  -h, --help            show this help message and exit　このヘルプメッセージを表示して終了する
  --dataset_path DATASET_PATH path of original dataset　元のデータセットのパス
  --output_path OUTPUT_PATH path of cleaned dataset　クリーンアップされたデータセットのパス
"--dataset_path"「元のデータセットのパス」"path of original dataset"　
"--output_path"「クリーンアップされたデータセットのパス」"path of cleaned dataset"　

画面表示
Clean dataset begin.
Total num=14344328
Retain num=13265314
Retain rate:0.9247776542756133
Clean dataset done.

処理内容
データrockyou.txtと出力ファイルrockyou-cleaned.txtを指定する
preprocess関数へ
rockyou.txtを読み込み用に開き、rockyou-cleaned.txtを書き込み用に開く
すべて読み込む(ファイルの改行が\r\nでも読み込み時に\rは消される)
rockyou.txtの重複を除去（順番は保持されないので変わる）
filter_password関数へ(4-12以外の長さとASCII以外の文字のパスワードを除外)
rockyou-cleaned.txtに有効なパスワードを書き込む
ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー

rockyou-cleaned.txtのパスワード(13265314)を学習用80%（rockyou-cleaned-Train.txt）とテスト用20%（rockyou-cleaned-Test.txt）に分ける
# 2. split into training set and test set　テストセット訓練セットを分離する（rockyou-cleaned.txtからrockyou-cleaned-Test.txtとrockyou-cleaned-Train.txtを作る）
python split_dataset.py --dataset_path=$cleaned_dataset --train_path=$training_dataset --test_path=$test_dataset
python split_dataset.py  --dataset_path=./dataset/rockyou-cleaned.txt  --train_path=./dataset/rockyou-cleaned-Train.txt   --test_path=./dataset/rockyou-cleaned-Test.txt

ヘルプ
usage: split_dataset.py [-h] --dataset_path DATASET_PATH --train_path TRAIN_PATH --test_path TEST_PATH [--ratio RATIO]
split_dataset.py: error: the following arguments are required: --dataset_path, --train_path, --test_path
options:
  -h, --help            show this help message and exit　このヘルプメッセージを表示して終了する
  --dataset_path DATASET_PATH path of cleaned dataset　クリーンアップされたデータセットのパス
  --train_path TRAIN_PATH save path of training set after split　分割後のトレーニングセットのパスを保存する
  --test_path TEST_PATH save path of test set after split　分割後のテストセットのパスを保存する
  --ratio RATIO         split ratio　分割比率
"--dataset_path"「クリーンアップされたデータセットのパス」"path of cleaned dataset"
"--train_path"「分割後のトレーニング セットのパスを保存する」"save path of training set after split"
"--test_path"「分割後のテストセットのパスを保存する」"save path of test set after split"
"--ratio"「分割比率」"split ratio"　default=0.8

画面表示
Split begin.
Shuffling passwords.
Saving 80% (10612251) of dataset for training in ./dataset/rockyou-cleaned-Train.txt
Saving 20% (2653063) of dataset for test in ./dataset/rockyou-cleaned-Test.txt
Split done.

処理内容
データrockyou.txtと出力ファイルrockyou-cleaned-Train.txt、rockyou-cleaned-Test.txtを指定する
rockyou-cleaned.txtを読み込み用に開く
rockyou-cleaned.txtをシャッフルする
パスワードの総数×0.8を計算する（0.8はデフォルト）
80%分のパスワードをrockyou-cleaned-Train.txtに書き込む
20%分のパスワードをrockyou-cleaned-Test.txtに書き込む
ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー

# 3. concat pattern and password together  パターンとパスワードを連結する（rockyou-cleaned-Train.txtからrockyou-cleaned-Train-ready.txtを作る）
python concat_pattern_password.py --dataset_path=$training_dataset --output_path=$ready4train_dataset
python concat_pattern_password.py  --dataset_path=./dataset/rockyou-cleaned-Train.txt  --output_path=./dataset/rockyou-cleaned-Train-ready.txt

ヘルプ
usage: concat_pattern_password.py [-h] --dataset_path DATASET_PATH --output_path OUTPUT_PATH
concat_pattern_password.py: error: the following arguments are required: --dataset_path, --output_path
options:
  -h, --help            show this help message and exit　このヘルプメッセージを表示して終了する
  --dataset_path DATASET_PATH path of training dataset after split　分割後のトレーニングデータセットのパス
  --output_path OUTPUT_PATH path of output dataset (ready for training)　出力データセットのパス（トレーニング準備完了）
"--dataset_path"「分割後のトレーニングデータセットのパス」"path of training dataset after split"
"--output_path"「出力データセットのパス（トレーニング準備完了）」"path of output dataset (ready for training)

処理内容
データockyou-cleaned-Train.txtと出力ファイルrockyou-cleaned-Train.txt、rockyou-cleaned-Train-ready.txtを指定する
rockyou-cleaned-Train.txtと読み込み用、rockyou-cleaned-Train-ready.txtを書き込み用に開く
rockyou-cleaned-Train.txtのパスワードを代入する
例：passwrod1
　　L8 S1のような構文を付ける
　　L8 N1 <SEP> p a s s w o r d 1をrockyou-cleaned-Train-ready.txtに書き込む
例：aaAA11!!
　　L4 N2 S2のような構文を付ける
　　L4 N2 S2 <SEP> a a A A 1 1 ! !をrockyou-cleaned-Train-ready.txtに書き込む
例：aA1!aA1!
　　L2 N1 S1 L2 N1 S1のような構文を付ける
　　L2 N1 S1 L2 N1 S1 <SEP> a A 1 ! a A 1 !をrockyou-cleaned-Train-ready.txtに書き込む