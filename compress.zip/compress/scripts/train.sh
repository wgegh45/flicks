dataset_name="rockyou"
ready4train_dataset="./dataset/${dataset_name}-cleaned-Train-ready.txt"

ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー

# 1. generate vocab file　　vocab.jsonを作る（既にある場合は何もしない）
python generate_vocab_file.py

ヘルプ
usage: generate_vocab_file.py [-h] [--save_path SAVE_PATH] [--max_len MAX_LEN]
generate_vocab_file.py: error: unrecognized arguments: 1
"--save_path"「語彙ファイルの保存パス」"save path of vocab file"　default='./tokenizer/vocab.json'
"--max_len"「データセット内のパスワードの最大長」"max length of password in datasets"　default=12

処理内容
./tokenizer/vocab.jsonがある場合は何もせず終わる
./tokenizer/vocab.jsonを書き込み用に開く
{ "<BOS>": 0, "<SEP>": 1, ・・・ "~": 134 }を書き込む
スペース(32)は含まない、94種類
ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー

# 2. train
python train.py                                                               --dataset_path=$ready4train_dataset
python train.py                                                               --dataset_path=./dataset/rockyou-cleaned-Train-ready.txt
python train.py  --model_name bert-base-uncased --dataset_path=./dataset/rockyou-cleaned-Train-ready.txt

ヘルプメッセージ
usage: train.py [-h] --dataset_path DATASET_PATH [--vocabfile_path VOCABFILE_PATH] [--model_path MODEL_PATH] [--log_path LOG_PATH] [--random_seed RANDOM_SEED]
                [--num_processer NUM_PROCESSER] [--input_size INPUT_SIZE] [--embed_size EMBED_SIZE] [--layer_num LAYER_NUM] [--head_num HEAD_NUM] [--epoch_num EPOCH_NUM]
                [--batch_size BATCH_SIZE] [--eval_step EVAL_STEP] [--save_step SAVE_STEP] [--early_stop EARLY_STOP]

# ファイルパスパラメータ設定
"--dataset_path"「前処理済みのトレーニングデータセットのパス」"path of preprocessed train dataset"
"--vocabfile_path"「単語ファイルのパス」"path of vocab file"
"--model_path"「モデルを保存するディレクトリ」"directory to save model"
"--log_path"「ログのディレクトリ」"directory of log"
# 環境パラメータ設定
"--random_seed"「ランダムシード」"random seed"　default=42
"--num_processer"　「プロセッサ数（CPUロジットコア）」　"num of processer (cpu logit cores)"　default=1
# モデルパラメータ設定
"--input_size"　"should be larger than (2*max len of password + 3), default is 32 according to max_len=12"　「(2*パスワードの最大長+3)より大きくする必要があります。デフォルトはmax_len=12に従って32です。」　default=32
"--embed_size"　「埋め込みサイズ」"embedding size"　default=384
"--layer_num"　「レイヤー数」"num of layers"　default=12
"--head_num"　「マルチヘッドの数」　"num of multi head"　default=8
# トレーニングパラメータ設定
"--epoch_num"　「エポック数（早期停止を含む）」"num of epoch (containing early stop))"　default=30
"--batch_size　「バッチサイズ」"Batchi saizu'"batch_size"　default=512　
"--eval_step"　「nステップごとにモデルを評価する」　"eval model every n steps"　default=2000
"--save_step"　「nステップごとにモデルを保存する」　"save model every n steps"　default=6000
"--early_stop"　「早期停止の忍耐」　"early stop patience"　default=3


表示
(base) C:\Users\Admin\Desktop\PagPassGPT\PagPassGPT>python train.py  --dataset_path=./dataset/rockyou-cleaned-Train-ready.txt
Namespace(dataset_path='./dataset/rockyou-cleaned-Train-ready.txt', vocabfile_path='./tokenizer/vocab.json', model_path='./model/', log_path='./log/', random_seed=42, num_processer=1, input_size=32, embed_size=384, layer_num=12, head_num=8, epoch_num=30, batch_size=512, eval_step=2000, save_step=6000, early_stop=3)
Load tokenizer.
CharTokenizer(name_or_path='', vocab_size=135, model_max_length=1000000000000000019884624838656, is_fast=False, padding_side='right', truncation_side='right', special_tokens={'bos_token': '<BOS>', 'eos_token': '<EOS>', 'unk_token': '<UNK>', 'sep_token': '<SEP>', 'pad_token': '<PAD>'}, clean_up_tokenization_spaces=True),  added_tokens_decoder={
        0: AddedToken("<BOS>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
        1: AddedToken("<SEP>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
        2: AddedToken("<EOS>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
        3: AddedToken("<UNK>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
        4: AddedToken("<PAD>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
}
Load dataset.
Generating train split: 114 examples [00:00, 13975.29 examples/s]
Map: 100%|███████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| 114/114 [00:00<?, ? examples/s]
Split dataset into training set and validation set.
Load model config.
Num parameters: 21358464
GPT2LMHeadModel(
  (transformer): GPT2Model(
    (wte): Embedding(135, 384)
    (wpe): Embedding(32, 384)
    (drop): Dropout(p=0.1, inplace=False)
    (h): ModuleList(
      (0-11): 12 x GPT2Block(
        (ln_1): LayerNorm((384,), eps=1e-05, elementwise_affine=True)
        (attn): GPT2Attention(
          (c_attn): Conv1D()
          (c_proj): Conv1D()
          (attn_dropout): Dropout(p=0.1, inplace=False)
          (resid_dropout): Dropout(p=0.1, inplace=False)
        )
        (ln_2): LayerNorm((384,), eps=1e-05, elementwise_affine=True)
        (mlp): GPT2MLP(
          (c_fc): Conv1D()
          (c_proj): Conv1D()
          (act): NewGELUActivation()
          (dropout): Dropout(p=0.1, inplace=False)
        )
      )
    )
    (ln_f): LayerNorm((384,), eps=1e-05, elementwise_affine=True)
  )
  (lm_head): Linear(in_features=384, out_features=135, bias=False)
)
******************************
Training begin.
{'train_runtime': 115.4685, 'train_samples_per_second': 25.721, 'train_steps_per_second': 0.26, 'train_loss': 2.5509821573893228, 'epoch': 30.0}
100%|█████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| 30/30 [01:55<00:00,  3.85s/it]
Model saved in ./model/last-step/
******************************
Training done.

処理内容
ファイルパスパラメータ設定





