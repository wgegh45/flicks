dataset_name="rockyou"
cleaned_dataset="./dataset/${dataset_name}-cleaned.txt"
model_path="./model/last-step/"
output_path="./generate/"

# 1. Get patterns rate
python get_pattern_rate.py --dataset_path=$cleaned_dataset
python get_pattern_rate.py --dataset_path="./dataset/rockyou-cleaned.txt"

ヘルプ
usage: get_pattern_rate.py [-h] --dataset_path DATASET_PATH [--output_path OUTPUT_PATH]
get_pattern_rate.py: error: the following arguments are required: --dataset_path
"--dataset_path"　「トレーニングデータセットのパス」　"path of training dataset"　--dataset_path="./dataset/rockyou-cleaned.txt"
"--output_path"　　「パターンレートのパスを保存」　　 "save path of pattern rate"　default="patterns.txt"

このファイルは、トレーニングセット（クリーニング）からパターンレートを取得することを目的としています。

処理内容
patterns.txtがあると処理しない（"./dataset/rockyou-cleaned.txt"が変わっても処理されないのはおかしい）
./dataset/rockyou-cleaned.txtを読み込み用に開き、./patterns.txtを書き込み用に開く
./dataset/rockyou-cleaned.txtのデータを取得する
./dataset/rockyou-cleaned.txtの行数を求める
各パスワードを取得する
各パスワードのPCFGパターン（L6 L5 L7 L6 ・・・ L8）を求める
各PCFGパターンの個数を求める
Pythonの辞書（pcfg_patterns_dict）を「値（value）で降順にソート」して、新しい辞書として再格納
PCFGパターンと比率をpatterns.txtに書き込む

ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー
# 2. Generate (use DC-GEN) by using no.4 and no.5 gpus (ids of gpus should be continuous)
python DC-GEN.py --model_path=$model_path          --output_path=$output_path --generate_num=1000000   --batch_size=5000 --gpu_num=2 --gpu_index=4
python DC-GEN.py --model_path=./model/last-step/ --output_path=./generate/     --generate_num=10000      --batch_size=5000 --gpu_num=1 --gpu_index=0
python DC-GEN.py --model_path=./model/last-step/ --output_path=./generate/     --generate_num=100         --batch_size 10      --cpu_threads 2
python DC-GEN.py --model_path=./model/last-step/  --output_path=./generate/    --generate_num=20000       --batch_size=5000     --gpu_num=1 --gpu_index=4



ヘルプ
usage: DC-GEN.py [-h] --model_path MODEL_PATH [--vocabfile_path VOCABFILE_PATH] [--pattern_path PATTERN_PATH] --output_path OUTPUT_PATH [--generate_num GENERATE_NUM]
                 [--save_num SAVE_NUM] [--batch_size BATCH_SIZE] [--cpu_threads CPU_THREADS]
DC-GEN.py: error: the following arguments are required: --model_path, --output_path

"--model_path"　「pagpassgptのディレクトリ」　"directory of pagpassgpt"
"--vocabfile_path"　「語彙ファイルのパス」　"path of vocab file"　default='./tokenizer/vocab.json'
"--output_path"　「出力ファイルパスのパス」　"path of output file path"
"--generate_num"　「合計推測数」　"total guessing number"　default=1000000
"--batch_size"　「バッチサイズを生成する」　"generate batch size"　default=5000
"--gpu_num"　「GPU番号」　"gpu num"　default=1
"--gpu_index"　「GPUインデックスの開始」　"Starting GPU index", default=0

"--pattern_path"　「パターンレートファイルのパス」　"path of pattern rate file"  default='patterns.txt'
"--save_num"　「1回生成されたパスワードごとに1回保存」　"per n passwords generated save once"　default=20000000

ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー

# 3. or Generate (not use DC-GEN) 
python normal-gen.py --model_path=$model_path           --output_path=$output_path --generate_num=1000000   --batch_size=5000  --gpu_num=2 --gpu_index=4
python normal-gen.py --model_path=./model/last-step/ --output_path=./generate/     --generate_num=10000       --batch_size=5000
python normal-gen.py --model_path=./model/last-step/ --output_path=./generate/     --generate_num=10000       --batch_size 1000  --cpu_threads 2
python normal-gen.py --model_path=./model/last-step/ --output_path=./generate/     --generate_num=100           --batch_size 10      --cpu_threads 2

ヘルプ
(base) C:\Users\Admin\Desktop\PagPassGPT\PagPassGPT>python normal-gen.py
usage: normal-gen.py [-h] --model_path MODEL_PATH [--vocabfile_path VOCABFILE_PATH] --output_path OUTPUT_PATH [--generate_num GENERATE_NUM] [--batch_size BATCH_SIZE]
                     [--cpu_threads CPU_THREADS]
normal-gen.py: error: the following arguments are required: --model_path, --output_path

"--model_path"　「pagpassgptのディレクトリ」　"directory of pagpassgpt"
"--vocabfile_path"　「語彙ファイルのパス」　"path of vocab file"　default='./tokenizer/vocab.json'
"--output_path"　「出力ファイルパスのパス」　"path of output file path"
"--generate_num"　「合計推測数」　"total guessing number"　default=1000000
"--batch_size"　「バッチサイズを生成する」　"generate batch size"　default=5000
"--gpu_num"　「GPU番号」　"gpu num"　default=1
"--gpu_index"　「GPUインデックスの開始」　"Starting GPU index", default=0


ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー


