from typing import Any, Dict, List, overload
import torch
import json
from transformers.tokenization_utils import PreTrainedTokenizer

# 語彙ファイルの読み込み、文字→ID、ID→文字、特殊トークン付与、encode_*/decode 相当の処理を行う
# 本ファイルで定義したカスタムトークナイザーを使って入力文字列をトークン列に変換する
# このリポジトリの場合は 文字単位のトークナイズ。
# 例えば "abc" → [id_a, id_b, id_c] のように変換される。
# 入力文字列を char_tokenizer でトークン化 → [1, seq_len] に整形

char = str


class CharTokenizer(PreTrainedTokenizer):
    vocab_files_names = {"vocab_file": "vocab.json"}  # 追加　./tokenizer/vocab.json
    
    
    def __init__(
        self,
        vocab_file, # ./tokenizer/vocab.json
        add_bos_and_eos: bool = True, # add_bos_and_eos=True
        padding_side='right',
###        bos_token=None,
###        eos_token=None,
###        sep_token=None,
###        unk_token=None,
###        pad_token=None,
           bos_token="<BOS>", # 変更
           eos_token="<EOS>", # 変更
           sep_token="<SEP>", # 変更
           unk_token="<UNK>", # 変更
           pad_token="<PAD>", # 変更
    ):
###        super().__init__(
###            bos_token=bos_token,
###            eos_token=eos_token,
###            pad_token=pad_token,
###            sep_token=sep_token,
###            unk_token=unk_token,
###        )
        self.add_bos_and_eos = add_bos_and_eos # True
        self.padding_side = padding_side       # right
        
        with open(vocab_file, encoding="utf-8") as vocab_handle: # vocab_handle=<_io.StringIO object at 0x00000242BDAA1090>
            self.vocab = json.load(vocab_handle)# 変更
            self.encoder = self.vocab           # 互換性のため追加
###         self.encoder = json.load(vocab_handle)

###     self.decoder = {v: k for k, v in self.encoder.items()}
        self.decoder = {v: k for k, v in self.vocab.items()}


###     self.bos_token_id = self.encoder[self.bos_token]
###     self.eos_token_id = self.encoder[self.eos_token]
###     self.sep_token_id = self.encoder[self.sep_token]
###     self.pad_token_id = self.encoder[self.pad_token]
###     self.unk_token_id = self.encoder[self.unk_token]

########### 追加 ############
        bos_token_id = self.vocab.get(bos_token) # 0
        eos_token_id = self.vocab.get(eos_token) # 2
        sep_token_id = self.vocab.get(sep_token) # 1
        pad_token_id = self.vocab.get(pad_token) # 4
        unk_token_id = self.vocab.get(unk_token) # 3

        super().__init__(
            bos_token=bos_token, # <BOS>
            eos_token=eos_token, # <EOS>
            pad_token=pad_token, # <PAD>
            sep_token=sep_token, # <SEP>
            unk_token=unk_token, # <UNK>
        )
        
        self.bos_token_id = bos_token_id # 0
        self.eos_token_id = eos_token_id # 2
        self.sep_token_id = sep_token_id # 1
        self.pad_token_id = pad_token_id # 4
        self.unk_token_id = unk_token_id # 3
        
        self.model_input_names = ["input_ids", "attention_mask"]       
        
    def save_vocabulary(self, save_directory, filename_prefix=None):
        import os
        filename = (filename_prefix + "-" if filename_prefix else "") + "vocab.json"
        path = os.path.join(save_directory, filename)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.vocab, f, ensure_ascii=False)
###         json.dump(self.encoder, f, ensure_ascii=False)
        return (path,)

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path, *init_inputs, **kwargs):
        import os
        vocab_file = os.path.join(pretrained_model_name_or_path, "vocab.json")
        return cls(vocab_file=vocab_file, **kwargs)
########### ここまで ##############

    @property
    def vocab_size(self):
        return len(self.vocab)
###     return len(self.encoder)

    def get_vocab(self):
        return dict(self.vocab)
###     return dict(self.encoder)
    
    def _tokenize(self, text: str) -> List[char]:
        if text == '': # N5  L8 N1
            return []
        # result = []
        # while len(text) != 0:
        #     is_hit = False
        #     for vocab in self.encoder:
        #         if text.startswith(vocab):
        #             result.append(vocab)
        #             text = text[len(vocab):]
        #             is_hit = True
        #             break
        #     if not is_hit:
        #         result.append(self.unk_token)
        #         text = text[1:]
        return text.strip(' ').split(' ')


    def _convert_token_to_id(self, token):
        """Converts a token (str) in an id using the vocab."""
        """vocab.jsonを使用して、ID 内のトークン (str) を変換します。"""
        return self.vocab.get(token, self.unk_token_id) # 変更
###     return self.encoder.get(token, self.encoder.get(self.unk_token))


    def _convert_id_to_token(self, index):
        """Converts an index (integer) in a token (str) using the vocab."""
        """語彙を使用してトークン (str) のインデックス (整数) を変換します。"""
        return self.decoder.get(index) # 変更
###        return self.decoder.get(index)
    

    def convert_tokens_to_string(self, tokens):
        """Converts a sequence of tokens (string) in a single string."""
        """トークンのシーケンス (文字列)を1つの文字列に変換します。"""
        text = "".join(tokens)
        return text
    
    
    def encode(self, text: str, return_is_tensor=False) -> Any:
        indices: List[int] = [self.vocab.get(c, self.unk_token_id) for c in self._tokenize(text)] # 変更
###     indices: List[int] = [self.encoder.get(c, self.unk_token_id) for c in self._tokenize(text)]
        if self.add_bos_and_eos:
            indices = [self.bos_token_id] + indices + [self.eos_token_id]
        if return_is_tensor:
            return torch.tensor(indices)
        else:
            return indices
 
    
    # pcfg_pattern(N5)から[0, 12]を作る L8N1から[0, 21, 16]を作る
    def encode_forgen(self, text: str) -> torch.Tensor: # text=N5　L8N1  _tokenize関数へ
    
        # vocab.jsonでN5は12  テキストをトークン化して、各トークンを辞書vocab.jsonを使って数値IDに変換し、その整数リストを indices に格納
        indices: List[int] = [self.vocab[c] for c in self._tokenize(text)] # 変更 [12] 
###     indices: List[int] = [self.encoder[c] for c in self._tokenize(text)]

        # トークン列の先頭に文の開始(BOSトークンIDの0を追加 [0, 12]　　[0, 21, 16]
        indices = [self.bos_token_id] + indices 
   
        return torch.tensor(indices) # tensor([ 0, 12])　　[0, 21, 16]
    
    
    # インデックス列（torch.Tensor）を文字列に変換する
    def decode(self, indices: torch.Tensor) -> str:
        chars = []
        for index in indices:
            index = int(index)   # Tensor → int にキャスト
            if index in [self.bos_token_id, self.eos_token_id, self.pad_token_id]:
                continue         # BOS, EOS, PAD はスキップ
            elif index == self.sep_token_id:
                decode_ans = ' ' # SEP はスペースに置換
            else:
                decode_ans = self.decoder[index]  # ID→文字のマッピング（例：{51:"A", 52:"B", ...}）
            chars.append(decode_ans) # charsを結合して文字列にする ['N5', ' ', '1', '&', '4', 'X', '1', '1', '1'] ['N5', ' ', 'm', 'e', 'r']
        return "".join(chars)



    @overload
    def __call__(self, texts: str, max_len=None, padding=False) -> Dict:
        ...
    @overload
    def __call__(self, texts: list, max_len=None, padding=False) -> Dict:
        ...
    def __call__(self, texts, max_len=None, padding=False) -> Dict:
        if not padding:
            if type(texts) == str:
                input_ids = self.encode(texts)
                attention_masks = [1] * len(input_ids)
                result = {"input_ids":input_ids, "attention_masks":attention_masks}
                return result
            else:
                assert(type(texts)==list)
                result = {"input_ids":[], "attention_masks":[]}
                for text in texts:
                    input_ids = self.encode(text)
                    attention_masks = [1] * len(input_ids)
                    result["input_ids"].append(input_ids)
                    result["attention_masks"].append(attention_masks)
                return result
        else:
            assert(max_len)
            if self.padding_side == 'right':
                if type(texts) == str:
                    input_ids = self.encode(texts)
                    length = len(input_ids)
                    input_ids += [self.pad_token_id] * (max_len - length)
                    attention_masks = [1] * length + [0] * (max_len - length)
                    result = {"input_ids":input_ids, "attention_masks":attention_masks}
                    return result
                else:
                    assert(type(texts)==list)
                    result = {"input_ids":[], "attention_masks":[]}
                    for text in texts:
                        input_ids = self.encode(text)
                        length = len(input_ids)
                        input_ids += [self.pad_token_id] * (max_len - length)
                        attention_masks = [1] * length + [0] * (max_len - length)
                        result["input_ids"].append(input_ids)
                        result["attention_masks"].append(attention_masks)
                    return result
            else:
                assert(self.padding_side=="left")
                if type(texts) == str:
                    input_ids = self.encode(texts)
                    length = len(input_ids)
                    padding = [self.pad_token_id] * (max_len - length)
                    input_ids = padding + input_ids
                    attention_masks = [0] * (max_len - length) + [1] * length
                    result = {"input_ids":input_ids, "attention_masks":attention_masks}
                    return result
                else:
                    assert(type(texts)==list)
                    result = {"input_ids":[], "attention_masks":[]}
                    for text in texts:
                        input_ids = self.encode(text)
                        length = len(input_ids)
                        padding = [self.pad_token_id] * (max_len - length)
                        input_ids = padding + input_ids
                        attention_masks = [0] * (max_len - length) + [1] * length
                        result["input_ids"].append(input_ids)
                        result["attention_masks"].append(attention_masks)
                    return result
                
                
    # トークンIDを文字列に変換する
    def batch_decode(self, indices:torch.Tensor) -> List[str]: # tensor([[ 0, 12,  1,  ...,  8,  2,  4],  [ 0, 12,  1,  ..., 47,  2,  4],           [ 0, 12,  1,  ..., 81,  2,  4],          ...,          [ 0, 12,  1,  ..., 42,  2,  4],          [ 0, 12,  1,  ...,  2,  4,  4],          [ 0, 12,  1,  ...,  4,  4,  4]], device='cuda:0')   [ 0, 21, 16,  ...,  4,  4,  4],  ・・・         [ 0, 21, 16,  ...,  4,  4,  4]], device='cuda:0')

        # トークンIDを1セットずつ文字列に変換
        result = [] 
        
        print(range(indices.shape[0]))
        for i in range(indices.shape[0]): # i=0 1 2 ・・・ 142  0 1 2 ・・・ 148
            result.append(self.decode(indices[i]))
            
        return result # パスワードを返す ['N5 s87neN9'] ['N5 s87neN9', 'N5 L11MN8456'] ・・・ ['N5 s87neN9', 'N5 L11MN8456', 'N5 covete', 'N5 celese', 'N5 12@45x', 'N5 123112N5', 'N5 die111S9', 'N5 a9N12L2ce', 'N5 cobthosx', 'N5 suthanZ', 'N5 jos123', 'N5 ja[els', 'N5 6:S3me4', 'N5 N12iverS12', 'N5 1@1S11', 'N5 vo32em', 'N5 s`L4get', 'N5 q%`,er', 'N5 sherba~', 'N5 dweer11e', 'N5 e;211!', 'N5 12345', 'N5 baO12e', 'N5 ftS3rie', 'N5 foP122c3', 'N5 1els33', 'N5 6h', 'N5 gattS10a', 'N5 S6L3abew', 'N5 sane12', 'N5 loP444L8', 'N5 123454', 'N5 !L5anep', 'N5 elomie', 'N5 s&eN9sVL', 'N5 shoney', 'N5 c2', 'N5 shorex', 'N5 yf3455', 'N5 p}7nS304', 'N5 s!ettC', 'N5 jeS121122', 'N5 chover', 'N5 S9andl3', 'N5 11S121241', 'N5 an^212', 'N5 sC`lo,', 'N5 9ma|a=', 'N5 11>vo2', 'N5 mo~bov', 'N5 123212', 'N5 99ftty', 'N5 121y', 'N5 =KN1143el', 'N5 boserzL11', 'N5 s12rS11e', 'N5 suhrik', 'N5 123L412', 'N5 11', 'N5 =a#12127', 'N5 c1112y', 'N5 frL4icE', 'N5 jesN1e!', 'N5 12331!', 'N5 cGarie', 'N5 s$eric', 'N5 sMvese', 'N5 1', 'N5 12311S', 'N5 hoN4eve', 'N5 saL11eha', 'N5 12345L11', 'N5 se', 'N5 cop}oS9', 'N5 j89989', 'N5 111125', 'N5 adin/e', 'N5 v2fN956', 'N5 \\[1S4V12', 'N5 surcbo1y', 'N5 ', 'N5 gesury', 'N5 345N511', 'N5 su^121', 'N5 12344L6', 'N5 1', 'N5 th:0L4e!', 'N5 posssy', 'N5 yL41L3N11', 'N5 323123', 'N5 1', 'N5 12Yx23', 'N5 sus45', 'N5 d23han9', 'N5 123N713', 'N5 pu121N7', 'N5 drty', 'N5 123112', 'N5 11', 'N5 cooL9p*', 'N5 1131', 'N5 1121@X', 'N5 1823rp', 'N5 12312123', 'N5 loN11er7', 'N5 siemo1', 'N5 12343o', 'N5 113r!s', 'N5 fnge1 fs', 'N5 1111b#N6', 'N5 996450', 'N5 123223', 'N5 L1N4c21', 'N5 1111211', 'N5 7ngele', 'N5 move=S3', 'N5 z23mo-', 'N5 t@eris', 'N5 magele', 'N5 alo12CL3', 'N5 fpobesS12', 'N5 12222!', 'N5 \\ov. 6', 'N5 a^1211', 'N5 A11~< ', 'N5 !e=yer', 'N5 123454', 'N5 9999994', 'N5 su12235', 'N5 1', 'N5 S1mbul', 'N5 s899123', 'N5 f$445xan', 'N5 and%ea', 'N5 S12elGs', 'N5 em1117L101', 'N5 5', 'N5 111', 'N5 lo7412', 'N5 eraurs', 'N5 N6112!1', 'N5 aKQL4r', 'N5 fron']
                                  # ['L8N1 lonesa!23', 'L8N1 lo45665', 'L8N1 rptyel', 'L8N1 hom ngeD', 'L8N1 ;bsuries', 'L8N1 9{%ifth;', 'L8N1 ar}t}', 'L8N1 oN1N1ger', 'L8N1 um:meN9th', 'L8N1 L4b`icotr', 'L8N1 *ctie', 'L8N1 anc}e', 'L8N1 meL2L4cak', 'L8N1 9u$ma', 'L8N1 h:t=Ghaw', "L8N1 p'm>S1u8S1ei}", 'L8N1 fopeihes', 'L8N1 ockbS1ic', 'L8N1 cpIsF>e1', 'L8N1 plriL2', 'L8N1 unpeL9oe9erm', 'L8N1 ssL11ic', 'L8N1 ho0i:ur', 'L8N1 jEcesp/', 'L8N1 hewerfY', 'L8N1 lico%e>', 'L8N1 lN1450|e', 'L8N1 lerS10S1jC21', 'L8N1 bonzS10', 'L8N1 riNS10S10c`cQ8L', 'L8N1 N245kle', 'L8N1 mie<S1TUcL10', 'L8N1 L4 anViL9L3elS', 'L8N1 thbTteS10]', 'L8N1 fbutel.1', 'L8N1 tt>chanr', 'L8N1 pomin7vX', 'L8N1 ushablos', 'L8N1 er*ly', 'L8N1 ppN1N1lss', 'L8N1 estby', 'L8N1 ove bnl', 'L8N1 ic`el>e', 'L8N1 c.spssty', 'L8N1 r`kihand', 'L8N1 rinket1', 'L8N1 nNr>S1 gell', 'L8N1 poynceiv', 'L8N1 iciN11.ppw', 'L8N1 aperH}r', 'L8N1 nf"emL9S4', 'L8N1 splolfur', 'L8N1 t0rinfla', 'L8N1 manS1in', 'L8N1 hix>bersf%X', 'L8N1 werica</%', "L8N1 'plicpp", 'L8N1 pTrpesss', 'L8N1 S5ytindoB', 'L8N1 joc^yoL9e', 'L8N1 tiwc23', 'L8N1 werin', 'L8N1 8mmo}7', 'L8N1 >h"L4esmaB-N12', 'L8N1 S1N1ricol', 'L8N1 leS10lkN1e', 'L8N1 u .cnssgL9cr', 'L8N1  pl`cow', 'L8N1 cansesN10eec', 'L8N1 evely', 'L8N1 anctgo', 'L8N1 cN1moner', 'L8N1 uyt!L10', 'L8N1 uirch', 'L8N1 8inonnis7', 'L8N1 bcL12yyott21q', 'L8N1 d9man/', 'L8N1 uncey', 'L8N1 uhwLcb+a', 'L8N1 S5j*p0eI1', 'L8N1 uwrTiey', "L8N1 'n}ls", 'L8N1 bpHicn24', 'L8N1 alrtell', 'L8N1 i:momaco', 'L8N1 umS10.nd3b', 'L8N1 upmoour', 'L8N1 ^bn ckr', 'L8N1  cL2eS95', 'L8N1 prgereel', 'L8N1 pbeolsss21e', 'L8N1 eslomell', 'L8N1 sgerinxN6', 'L8N1 <arielof', 'L8N1 ca0 roh', 'L8N1 of0 L2hol', 'L8N1 pertw', 'L8N1 ei}lev', 'L8N1 nericon', 'L8N1 ratelc3', 'L8N1 a>} jouhamm', 'L8N1  arS2co[3', 'L8N1 ` "chlL113L1', 'L8N1 k>kbobb', 'L8N1 bL6ler', 'L8N1 sonilseS9', 'L8N1 hGssi}3', 'L8N1 erinel', 'L8N1 fmeS1 ha1', 'L8N1 p~%bangN5', 'L8N1 hamiterl', 'L8N1 suyi}allS9', 'L8N1 b lotL2L11L4', 'L8N1 inVGa', 'L8N1 jebeter', 'L8N1 ert(fmav', 'L8N1 >o hhN12N5', 'L8N1 leelew', 'L8N1 bo"lelf/', 'L8N1 s}0staerI.', 'L8N1 oriZn', 'L8N1 uS1k yan', 'L8N1 .i%ege', 'L8N1 r uiiina', 'L8N1 =rerHfl', 'L8N1 }cypovex', 'L8N1 mur alo', 'L8N1 *ibcb7', 'L8N1 ope!poS9j', 'L8N1 scer p3', 'L8N1 anich', 'L8N1 emiOsL11el', 'L8N1 ;{mttfle', 'L8N1 *esiZng10D', 'L8N1 mchua', 'L8N1 mgeielik', 'L8N1 ofrpS5r:', 'L8N1 u>%ane>', 'L8N1 mbsyane', 'L8N1 hopinL1rf', 'L8N1 yelien', 'L8N1 umeln', 'L8N1 cyetinL2a', 'L8N1 ichic7e', 'L8N1 l`4iN1aulleS4', 'L8N1 572bmeel', 'L8N1 ^ricc23', 'L8N1 ^inN3iS10']

def main():
    vocab_file = "vocab.json"

    tokenizer = CharTokenizer(vocab_file=vocab_file, 
                              bos_token="<BOS>",
                              eos_token="<EOS>",
                              sep_token="<SEP>",
                              unk_token="<UNK>",
                              pad_token="<PAD>"
                            )

    print(f"vocab_size: {tokenizer.vocab_size}")

    texts = ["L4 N3 S1 <SEP> P a s s 1 2 3 $"]

    for text in texts: 
        indices = tokenizer.encode(text, return_is_tensor=True)
        reconstructed_text = tokenizer.decode(indices)
        
        print('inputs:{}'.format(text))
        print('encoded:{}'.format(indices))
        print('decoded:{}'.format(reconstructed_text))


if __name__ == "__main__":
    main()
