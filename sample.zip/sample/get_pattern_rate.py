# This file aims to get patterns rate from training set (cleaned).
# このファイルは、トレーニングセット（クリーニング）からパターンレートを取得することを目的としています。

from concat_pattern_password import get_pattern
import argparse
import os

parser = argparse.ArgumentParser()
parser.add_argument("--dataset_path", help="path of training dataset", type=str, required=True)
parser.add_argument("--output_path", help="save path of pattern rate", type=str, default="patterns.txt")
args = parser.parse_args()
#print(args)
# Namespace(dataset_path='./dataset/rockyou-cleaned.txt', output_path='patterns.txt')

train_dataset_path = args.dataset_path  # ./dataset/rockyou-cleaned.txt
PCFG_rate_file = args.output_path       # ./patterns.txt


if not os.path.isfile(PCFG_rate_file): # patterns.txtがあると処理しない
    # ./dataset/rockyou-cleaned.txtを読み込み用に開き、./patterns.txtを書き込み用に開く
    f_in = open(train_dataset_path, 'r', encoding='utf-8', errors='ignore')
    f_out = open(PCFG_rate_file, 'w', encoding='utf-8', errors='ignore')

    # 初期化
    pcfg_patterns_dict = {}

    # ./dataset/rockyou-cleaned.txtを読み込む
    lines = f_in.readlines()
    
    # ./dataset/rockyou-cleaned.txtの行数を求める
    total_num = len(lines) # 143
    
    
    for line in lines:
        if not line: # 空行のとき処理しない
            continue

        password = line[:-1] # -1は改行\nを除外するため
        print(password) # adrian teamo patrick iloveu ・・・ iloveyou
        
        pcfg_pattern = ' '.join(get_pattern(password))
        print(pcfg_pattern) # L6 L5 L7 L6 ・・・ L8

        # PCFGパターンの個数を求める
        if pcfg_pattern in pcfg_patterns_dict:      # 2回目以降のパターンのとき
            pcfg_patterns_dict[pcfg_pattern] += 1
        else:                                       # 初めてのパターンのとき
            pcfg_patterns_dict[pcfg_pattern] = 1
        print(pcfg_patterns_dict[pcfg_pattern]) # 1 1 1 2 ・・・ 19
        print(pcfg_patterns_dict) # {'L6': 1} {'L6': 1, 'L5': 1} {'L6': 1, 'L5': 1, 'L7': 1} {'L6': 2, 'L5': 1, 'L7': 1} ・・・ {'L6': 61, 'L5': 4, 'L7': 27, 'L8': 19, 'N6': 11, 'N9': 2, 'L9': 9, 'N8': 1, 'L10': 2, 'L8 N1': 2, 'N5': 2, 'L3 N3': 1, 'N7': 1, 'N10': 1}

    # Pythonの辞書（pcfg_patterns_dict）を「値（value）で降順にソート」して、新しい辞書として再格納
    pcfg_patterns_dict = dict(sorted(pcfg_patterns_dict.items(), key=lambda x:x[1], reverse=True))
    print(pcfg_patterns_dict) # {'L6': 61, 'L7': 27, 'L8': 19, 'N6': 11, 'L9': 9, 'L5': 4, 'N9': 2, 'L10': 2, 'L8 N1': 2, 'N5': 2, 'N8': 1, 'L3 N3': 1, 'N7': 1, 'N10': 1}

    # PCFGパターンと比率をpatterns.txtに書き込む
    for key,value in pcfg_patterns_dict.items():
        f_out.write(f'{key}\t{value/total_num}\n')
        print(key)          # L6 L7  ・・・ N10 
        print(value)        # 61 143 ・・・ 1
        print(total_num)    # 143 143 ・・・ 143