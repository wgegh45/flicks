# This file aims to train a PagPassGPT.
# このファイルは、PagPassGPT をトレーニングすることを目的としています。

from tokenizer.char_tokenizer import CharTokenizer
from transformers import DataCollatorForLanguageModeling
from datasets import load_dataset
from transformers import GPT2Config
from transformers import GPT2LMHeadModel
from transformers import Trainer, TrainingArguments, EarlyStoppingCallback
import time
import argparse

# Python の argparse モジュールを使って コマンドライン引数を解析するためのパーサー（解析器）を作る（引数を渡した場合、それらを分解する）
parser = argparse.ArgumentParser()

# file path parameter setting
# ファイルパスパラメータ設定 # required=Trueはコマンドライン引数を必須　type=strは値が文字列型であることを指定　ヘルプに"path of preprocessed train dataset" と表示
parser.add_argument("--dataset_path", help="path of preprocessed train dataset", type=str, required=True)
parser.add_argument("--vocabfile_path", help="path of vocab file", type=str, default="./tokenizer/vocab.json")
parser.add_argument("--model_path", help="directory to save model", type=str, default="./model/")
parser.add_argument("--log_path", help="directory of log", type=str, default="./log/")

# environment parameter setting
# 環境パラメータ設定
parser.add_argument("--random_seed", help="random seed", type=int, default=42)
parser.add_argument("--num_processer", help="num of processer (cpu logit cores)", type=int, default=1)

# model parameter setting
# モデルパラメータ設定
parser.add_argument("--input_size", help="should be larger than (2*max len of password + 3), default is 32 according to max_len=12", type=int, default=32)
parser.add_argument("--embed_size", help="embedding size", type=int, default=384)
parser.add_argument("--layer_num", help="num of layers", type=int, default=12)
parser.add_argument("--head_num", help="num of multi head", type=int, default=8)

# training parameter setting
# トレーニングパラメータ設定
parser.add_argument("--epoch_num", help="num of epoch (containing early stop))", type=int, default=30)
parser.add_argument("--batch_size", help="batch_size", type=int, default=512)
parser.add_argument("--eval_step", help="eval model every n steps", type=int, default=2000)
parser.add_argument("--save_step", help="save model every n steps", type=int, default=6000)
parser.add_argument("--early_stop", help="early stop patience", type=int, default=3)

# ArgumentParser で定義したコマンドライン引数を 実際の実行時の引数に基づいて解析し、オブジェクトとして返す
args = parser.parse_args()
#print(args)
# Namespace(
# dataset_path='./dataset/rockyou-cleaned-Train-ready.txt', 
# vocabfile_path='./tokenizer/vocab.json', 
# model_path='./model/', 
# log_path='./log/', 
# random_seed=42, 
# num_processer=1, 
# input_size=32, 
# embed_size=384, 
# layer_num=12, 
# head_num=8, 
# epoch_num=30, 
# batch_size=512, 
# eval_step=2000, 
# save_step=6000, 
# early_stop=3)

train_dataset_path = args.dataset_path	# ./dataset/rockyou-cleaned-Train-ready.txt
vocab_file = args.vocabfile_path        # ./tokenizer/vocab.json
model_output_dir = args.model_path      # ./model/
log_dir = args.log_path                 # ./log/

random_seed = args.random_seed      # 42
num_processer = args.num_processer  # 1

# model params: 14260608
input_size = args.input_size # 32
embed_size = args.embed_size # 384
layer_num = args.layer_num   # 12
head_num = args.head_num     # 8

epoch_num = args.epoch_num   # 30
batch_size = args.batch_size # 512
eval_step = args.eval_step   # 2000
save_step = args.save_step   # 6000
early_stop = args.early_stop # 3


print(f'Load tokenizer.')
# トークナイザー（「パスワードの文字をモデルに分かち書きする道具」）の定義
# 「a」「b」「3」「$」など全部1文字ずつ扱う
# 単語単位ではなく、文字ごとにID（インデックス）を割り当てる。文字などを数字に変える
# こうして、パスワードを「1文字ごとの数字」に変えて学習できるようにします。
# 語彙中に特殊トークンも含まれ、モデルに文頭・文末などを示すことが可能。
# CharTokenizer（1文字＝1トークンで扱うカスタム文字トークナイザ、文字単位でトークン化する特別なトークナイザー）を、指定の語彙表（vocab_file）と各種特別トークンで初期化
# vocab_file には、ASCII文字＋パターン用トークンを含む辞書が入っており、合計135前後の語彙が使われます
# vocab_file
#  「文字とIDの対応表」を持つ。vocab.jsonでは"<BOS>": 0,"<SEP>": 1,・・・。語彙にない文字が出たら <UNK> のIDを使う
#  文字レベルの語彙表ファイル。1行に1シンボル（例：a、b、。、空白、<newline> など）を並べる。Unicode をそのまま並べる実装が一般的
#  文字種をどう入れるかは設計次第（ASCIIのみ／全角記号／かな・漢字／改行やタブをどう表現するか等）。
# 　文字とIDの対応表（語彙ファイル）
#  語彙にない文字が出たら <UNK> のIDを使
# bos_token="<BOS>" / eos_token="<EOS>"
#  Begin Of Sequence（文の開始を示す）
#  End Of Sequence（文の終了を示す）
#  文章の開始/終了を明示する特別トークン。生成や言語モデル学習でほぼ必須。
#  文の先頭、末尾に追加するトークン
# sep_token="<SEP>"
#  2文入力（NLI/QA など）の区切り。チャット形式の区切りとしても使えます。
#  セパレーター（文やセクション区切り用）（文と文の間や、段落区切りなど）
# unk_token="<UNK>"
#  語彙にない文字に出会ったときの代替。
#  語彙にない文字に置き換えるトークン（例: 未登録の絵文字など）
# pad_token="<PAD>"
#  バッチ化のため、系列を同じ長さに揃える。（学習や推論時のバッチ処理用）
# この設定を使うと…どんなテキストでも1文字単位に変換できる
# CharTokenizer が vocab.json を読み込み、入力文字列を トークン化 → ID 化 してモデルに渡せる形に変換する（モデルはその ID を入力として学習）
tokenizer = CharTokenizer(vocab_file=vocab_file, 
                          bos_token="<BOS>",
                          eos_token="<EOS>",
                          sep_token="<SEP>",
                          unk_token="<UNK>",
                          pad_token="<PAD>",
                          )
#print(tokenizer)
# CharTokenizer(name_or_path='', vocab_size=135, model_max_length=1000000000000000019884624838656, is_fast=False, padding_side='right', truncation_side='right', special_tokens={'bos_token': '<BOS>', 'eos_token': '<EOS>', 'unk_token': '<UNK>', 'sep_token': '<SEP>', 'pad_token': '<PAD>'}, clean_up_tokenization_spaces=False, added_tokens_decoder={
#        0: AddedToken("<BOS>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#        1: AddedToken("<SEP>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#        2: AddedToken("<EOS>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#        3: AddedToken("<UNK>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#        4: AddedToken("<PAD>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#}
# vocab_size=135 トークナイザーが認識する文字・特殊トークンの総数（135個の文字や特殊トークンがあるという意味）
# model_max_length=1000000...856　モデルで処理できる最大の入力長（トークン数）、非常に大きな値で事実上「制限なし」を表す
# is_fast=False RustやC++の高速版ではなく、読みやすく拡張しやすいが速度は遅めである純Python版であることを表す
# padding_side='right' 短い文章を 右側に <PAD> を挿入してバッチの長さを揃える設定
# truncation_side='right' 長すぎる文章は右端を削って指定長にする設定
# clean_up_tokenization_spaces=False デコード時に余計な空白や改行を削除しない設定
# added_tokens_decoder(特殊トークンの詳細設定) の各フラグ
#  rstrip=False / lstrip=False : トークンの右側の空白を自動削除しない 例: " <BOS> " の右空白は残る
#  single_word=False : トークンが単語単位でのみ使われる制約を持たない。文中のどの位置でも <BOS> を出せる
#  normalized=False : 正規化（例: 大文字小文字変換、Unicode正規化）をしない
#  special=True : モデルはこのトークンを特別扱い(文字列を分割しない、IDが予約されるなど)する
# 特殊トークン（<SEP>, <EOS>, <UNK>, <PAD>） も全て rstrip=False, lstrip=False, single_word=False, normalized=False, special=True に設定
#  つまり どの文字位置でも使えて、改変されずにそのまま扱う

print(f'Load dataset.')
# データ準備とデータ整形（言語モデル用のデータ整形を自動的に行う）
# パスワードを読み込み、長さを揃える。短いものは 右に<PAD> を足す（pad_to_multiple_ofがFalseなので倍数には揃えない）
data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)
# tokenizer 使用するトークナイザー（この場合 CharTokenizer）。トークンID変換や特殊トークン情報を参照
#  tokenizer が持つ特殊トークン情報 (<PAD>, <BOS>, <EOS> など) を参照してパディングやシーケンス境界を管理
# mlm(Masked Language Modeling)を使うか。　False = Causal LM（文生成用,GPTスタイルの次語予測トレーニング） / True = MLM（BERTタイプのマスク学習）。
#   mlm=False の場合: マスク化はせず、Causal LM用の入力をそのまま返す
#   Causal LM(因果言語モデル):次のトークンを予測するために学習、Hello, my name is → 次の単語 John を予測、マスクを使わない
# DataCollatorForLanguageModeling は「整形・バッチ化」に特化しており、トークナイザーの文字→ID変換や特殊トークンの扱いはトークナイザーに依存

#print(data_collator)
# DataCollatorForLanguageModeling(tokenizer=CharTokenizer(name_or_path='', vocab_size=135, model_max_length=1000000000000000019884624838656, is_fast=False, padding_side='right', truncation_side='right', special_tokens={'bos_token': '<BOS>', 'eos_token': '<EOS>', 'unk_token': '<UNK>', 'sep_token': '<SEP>', 'pad_token': '<PAD>'}, clean_up_tokenization_spaces=True),  added_tokens_decoder={
#	0: AddedToken("<BOS>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#	1: AddedToken("<SEP>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#	2: AddedToken("<EOS>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#	3: AddedToken("<UNK>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#	4: AddedToken("<PAD>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#}, mlm=False, mlm_probability=0.15, pad_to_multiple_of=None, tf_experimental_compile=False, return_tensors='pt')
# mlm_probability	MLM用マスク確率。デフォルト0.15。mlm=False なら無視されます。
# pad_to_multiple_of  パスワードの長さを指定した倍数に揃えるか。例: 8, 16。Noneなら揃えない
# tf_experimental_compile  TensorFlow で tf.function(experimental_compile=True) を使うか。PyTorchでは影響なし。
# return_tensors 出力テンソルの形式。'pt' = PyTorch, 'tf' = TensorFlow, 'np' = NumPy。
#  return_tensors='pt' により、PyTorch の torch.Tensor に変換(バッチサイズ x シーケンス長のテンソルとして出力)
# バッチは、学習や推論を高速化するために、複数の入力サンプルをまとめて処理すること
#  元の文章: ["Hello", "World!"]
#  文字単位トークン化: [[H,e,l,l,o],[W,o,r,l,d,!]]
#  バッチ化すると、 [[H,e,l,l,o, <PAD>], [W,o,r,l,d,!]]
# PyTorchテンソル
#  tensor([[ 0,  8,  5, 12, 12, 15,  1,  4,  4,  4],
#          [ 0, 23, 15, 18, 12,  4,  1,  4,  4,  4]])
#  1行 = 1文章  1列 = 1トークン  同じ列長に <PAD> で揃えている
# Causal LM
#  目的: 各時刻で「次のトークン」を予測
#  未来の情報は見ない（左から右の順序）
#  PADやBOS/EOSの扱い
#    <PAD>: 損失計算に含めない（無視）
#    <BOS>: 最初の入力トークン
#    <EOS>: 文章の終端（次を予測する対象にはならない）
#  モデルは 左のトークンを見て右のトークンを予測 <BOS>=0からH=8、H=8からe=5

# テキストファイルからデータセットをロード。
# load_dataset によりテキストファイル（例：rockyou.txt）を読み込む。
train_dataset = load_dataset('text', data_files=train_dataset_path, num_proc=num_processer, split='train') # ./dataset/rockyou-cleaned-Train-ready.txt 1
#print(train_dataset) # トークナイズ前
#Dataset({
#    features: ['text'],
#    num_rows: 114
#})
# 'text'	データセットの形式。ここでは テキストファイル を読み込む
# data_files=train_dataset_path	読み込むファイルパス
# num_proc=num_processer	データ読み込みや処理に使うプロセス数
# split='train'	データセットをどの分割で読み込むか	'train' を指定すると、返されるのは「学習用データセット」のみ

# トークナイズ（文字列 → トークンID）
# 文章をID列に変換、パディングと切り詰めも同時に行う
# 最大長（max_len = input_size）でパディング。
# 各行を最大 input_size=32 トークンに分割、パディング。
train_dataset = train_dataset.map(lambda examples: tokenizer(examples['text'], max_len=input_size, padding=True), batched=True) # 32
#print(train_dataset) # トークナイズ後
# Dataset({
#    features: ['text', 'input_ids', 'attention_masks'],
#    num_rows: 114
#})
# map()	
#  データセットの各サンプルに関数を適用して新しい列やデータを作る
#  データセットの各サンプル（行）に対して関数を適用するメソッド
#  元のデータに 新しい列を追加したり、既存列を変換したり できる
# lambda examples: tokenizer(...)	無名関数(名前を持たない小さな関数)で文章をトークナイズ
#  map() 内で使うと、簡潔にその場で関数を定義できる
#  examples は 複数サンプル('Hello', 'World'など)の辞書
# max_len=input_size	文章を切り詰める最大トークン数
# examples['text'] は文章（または文章リスト）であることを表す
# padding=True	バッチ内で短い文章を <PAD> で揃える
# batched=True  一度に複数文章をまとめて処理。GPU/CPU効率化に有効。
# トークナイザー: 文字列をモデルが理解できるID列に変換するツール
# ID列: 各文字や特殊トークンを数値で表したもの
#  Text: Hello  -> IDs: [0, 8,  5, 12, 12, 15, 1, 4, 4, 4]
#  Text: World! -> IDs: [0, 23, 15, 18, 12, 4, 1, 4, 4, 4]
#     <BOS> = 0: 文の先頭
#    <EOS> = 1: 文の末尾
#    <PAD> = 4: パディング（長さ揃え）
#  文字ごとのID: H → 8, e → 5, など
#  max_len=10のとき: 10トークンに揃えるため、足りない部分は <PAD> で埋める
# features	各列の名前（text, input_ids, attention_maskなど）
# num_rows	データサンプルの数
# input_ids は 文字や単語を数字に変換した列
#      'input_ids': [[0, 8, 5, 12, 12, 15, 1, 4, 4, 4],
#                    [0, 23, 15, 18, 12, 4, 1, 4, 4, 4]],
# attention_mask は PADトークンを無視するためのマスク列
#      'attention_mask': [[1,1,1,1,1,1,1,0,0,0],
#                         [1,1,1,1,1,1,1,0,0,0]]

print(f'Split dataset into training set and validation set.') # データセットを訓練セットと検証セットに分割
# データセットの分割（train / test）
# 12.5% を評価データセットとして分離(eval_dataset, train_dataset に切り分け)
# 12.5％は「テスト用」に分けて残します。
train_dataset= train_dataset.train_test_split(test_size=0.125)
#print(train_dataset)
#DatasetDict({
#    train: Dataset({
#        features: ['text', 'input_ids', 'attention_masks'],
#        num_rows: 99
#    })
#    test: Dataset({
#        features: ['text', 'input_ids', 'attention_masks'],
#        num_rows: 15
#    })
#})
# train_test_split(test_size=0.125)	 学習データセットを 87.5% 学習用 / 12.5% 評価用 に分割する関数
# eval_dataset = train_dataset['test']	評価用データセットとして保存 学習後のモデル性能評価に使用
# train_dataset = train_dataset['train']	学習用データセットとして保存	学習時にこのデータを使う
# DatasetDict は複数の Dataset をまとめた構造（train/test/validation など）
eval_dataset = train_dataset['test']
#print(eval_dataset)
# Dataset({
#    features: ['text', 'input_ids', 'attention_masks'],
#    num_rows: 15
#})
train_dataset = train_dataset['train']
print(train_dataset)
# Dataset({
#    features: ['text', 'input_ids', 'attention_masks'],
#    num_rows: 99
#})
# 全体の流れ
#   元のテキストデータを読み込む
#   map() で 文字列 → ID列 + attention_mask に変換
#   データセットに 新しい列('input_ids', 'attention_masks')が追加される
#   train_test_split で 訓練用と評価用に分割
#   最終的にモデル学習で使える形式になる

print(f'Load model config.')
# モデル設定（GPT2Config） モデルをどう作るか決める！
# モデルの大きさを設定。どれくらい学習するか設計
# これで「どれくらい頭の良いモデルにするか」が決まります
# vocab_size：トークナイザーの語彙数（可視ASCII＋特殊トークンなど）。
# n_positions：最大入力長（例：32トークン）。
# n_embd：各トークンの埋め込み次元数。
# n_layer：Transformer ブロックの数。
# n_head：マルチヘッドアテンションのヘッド数。
config = GPT2Config(                    # config → モデル構造とハイパーパラメータ
    vocab_size=tokenizer.vocab_size,    # 語彙数：トークナイザーが認識するユニークなトークンの数（文字・特殊トークン含む） 135
    n_positions=input_size,             # 最大入力長（例：32トークン）。（位置埋め込みの長さ）。最大32文字まで見るよ
    n_embd=embed_size,                  # 各トークンの埋め込み次元数。（各トークンを表現する次元数） 384  各文字を384次元（たとえば384色の色塗りみたいなイメージ）で覚える。512に増やせば約1.8倍のパラメータ数になりますが、表現力は上がります
    n_layer=layer_num,                  # Transformerブロックの数。（層の数）Transformer層 12　レイヤー層が12段
    n_head=head_num,                    # マルチヘッドアテンションのヘッド数 8　注意を払う部分を8方向見るようにする
    bos_token_id=tokenizer.bos_token_id,# 文の開始トークンID 0
    eos_token_id=tokenizer.eos_token_id,# 文の終了トークンID 2 文章の終了を示す特殊トークンID <EOS> トークンを学習時に挿入 eos_token_id=2 → <EOS> トークンを学習時に挿入
    activation_function="gelu_new",     # 活性化関数 Gaussian Error Linear Unit の改良版 非線形変換で情報を複雑に扱えるようにする
    resid_pdrop=0.1,                    # 残差結合（residual）にかけるドロップアウト率
    embd_pdrop=0.1,                     # 埋め込み層のドロップアウト率
    attn_pdrop=0.1,                     # Attentionのドロップアウト率
    layer_norm_epsilon=1e-5,            # LayerNormの安定化用微小値
    initializer_range=0.02,             # 重み初期化の標準偏差
    scale_attn_by_inverse_layer_idx=False, # 層番号で注意スコアをスケーリングするか 各Transformer層の注意スコアに層番号でスケーリングを掛けるか
                                           # True にすると深い層のスコアを小さくできるが、計算やハイパーパラメータ調整が必要 標準GPT2では不要
    reorder_and_upcast_attn=False,         # Attention計算時に精度アップキャスト(32bit → 64bit)や順序入れ替えをするか
                                           # 精度上の問題がほぼなく、通常の学習ではFalseで十分
)
# 位置埋め込み（n_positions）	トークンの順序情報を表現するベクトル、入力トークン列に順序情報を持たせるためのベクトルの長さ
#                        　  GPT系モデルは自己注意（Self-Attention）を使うため、位置情報を直接扱えないため、各トークンに 「何番目に出現するか」 を表す位置ベクトルを加算
#                           最大32トークンまで順序情報を保持可能 入力がこれを超えると、位置情報がなくなる
# 埋め込みベクトル（n_embd）	トークンIDをベクトル化した表現 1トークンを表す連続値ベクトルの次元数
#                       トークンIDを連続空間に写像することで、意味情報や類似性を学習 各トークンは384次元ベクトルで表現される
#                       値を増やすと表現力は上がるがパラメータ数と計算量も増加
# マルチヘッドアテンションのヘッド数（n_head） 注意機構で並列に見る方向の数
#                               各ヘッドは入力の異なる特徴や依存関係を捉える ヘッド数が少なすぎると表現力不足、多すぎると計算量増
#                               8通りの異なる注意パターンで情報を抽出
#                               各ヘッドの埋め込み次元は n_embd / n_head  384/8=48
# 残差結合（Residual）	前層の出力を足し合わせて勾配消失を防ぐ
# ドロップアウト（Dropout）	過学習防止のため、一定割合のノードを無効化
# アテンションスコアの計算式Attention(Q,K,V)=softmax(​QK^T / √dk​)V
#     Q：Query ベクトル（各位置の「質問」）
#     K：Key ベクトル（各位置の「見出し」）
#     V：Value ベクトル（各位置の「内容」）
#    dk​：各ヘッドのベクトル次元数
#   スケーリングとは、アテンションスコアの計算式の√dk​で割る部分
#     次元数が大きいと、QKTQKT の値が大きくなり、softmax の出力がほぼ 0 or 1 に近づく（＝勾配消失）。対策として、分散を抑えるために √dkで割り、値を安定させる

#print(config)
#GPT2Config {
#  "activation_function": "gelu_new", # GELU（Gaussian Error Linear Unit）の改良版で、MLP部分で非線形性を与える。ReLUより滑らかな勾配
#  "attn_pdrop": 0.1, # アテンションスコアに対する Dropout 率（10%）。過学習防止
#  "bos_token_id": 0, # Beginning of Sentence（文章開始）トークンのID。入力の先頭に付ける。
#  "embd_pdrop": 0.1, # 単語埋め込み（Embedding層）の出力に対する Dropout 率。
#  "eos_token_id": 2, # End of Sentence（文章終了）トークンのID。生成終了判定にも使う。
#  "initializer_range": 0.02,   # 重み初期化の標準偏差（正規分布）。小さいほど初期値が安定。
#  "layer_norm_epsilon": 1e-05, # LayerNormでゼロ割防止に加える微小値。
#  "model_type": "gpt2",        # モデルの種類
#  "n_embd": 384,               # 埋め込みベクトルの次元数。全層で統一。
#  "n_head": 8,                 # マルチヘッドアテンションのヘッド数。並列で8種類の視点を持つ。
#  "n_inner": null,             # MLPの中間層の次元数（指定なしの場合、4×n_embd が使われる）。
#  "n_layer": 12,               # Transformerブロックの層数。
#  "n_positions": 32,           # 最大位置埋め込み長（文長の上限）。
#  "reorder_and_upcast_attn": false, # アテンション計算時の並び替え＆高精度計算を無効化（速度優先）。
#  "resid_pdrop": 0.1,          # 残差接続（Residual connection）後の Dropout 率。
#  "scale_attn_by_inverse_layer_idx": false, # 層番号に応じた逆数スケーリングを無効化（固定スケーリングのみ）。
#  "scale_attn_weights": true,  # アテンションスコアを √dₖ で割るスケーリングを有効化。
#  "summary_activation": null,  # summary_ 系* モデル全体の出力をまとめる手法（BERT系で主に使用、GPTでは未使用）。
#  "summary_first_dropout": 0.1,
#  "summary_proj_to_labels": true,
#  "summary_type": "cls_index",
#  "summary_use_proj": true,
#  "transformers_version": "4.41.2", # Hugging Face Transformers のバージョン。
#  "use_cache": true,                # 推論時に過去のキー・バリューをキャッシュ（生成高速化）。
#  "vocab_size": 135                 # トークンの総数（語彙サイズ）。
#}
# config（例: GPT2Config）
# 公式ドキュメント:
# https://huggingface.co/docs/transformers/main/en/model_doc/gpt2#transformers.GPT2Config
# ソースコード: __init__ の引数
# https://github.com/huggingface/transformers/blob/main/src/transformers/models/gpt2/configuration_gpt2.py


# モデルインスタンス作成 モデルにその設定を渡す
# ここで実際にモデルの箱（プログラム）を作ります。
# モデルを作る。GPT‑2の箱を作成
# 「GPT‑2」っていう有名な仕組みを使っています。
# 自然言語生成（次語予測）用の出力ヘッドが付いた GPT-2モデルを指定した構成で初期化。
# 次語予測に特化した出力層（lm_head）が挿入されます
model = GPT2LMHeadModel(config=config) # model → 実際の層構成
print(f"Num parameters: {model.num_parameters()}") # Num parameters: 21358464
print(model)
# GPT2LMHeadModel(
#  (transformer): GPT2Model(     # GPT2本体（エンコーダ層相当）
#    (wte): Embedding(135, 384)  # Word Token Embedding：トークンID → ベクトル（135語彙×384次元）
#    (wpe): Embedding(32, 384)   # Word Position Embedding：位置ID → ベクトル（32位置×384次元）
#    (drop): Dropout(p=0.1, inplace=False) # Dropout：汎化性能向上のためのノード無効化
#    (h): ModuleList(
#      (0-11): 12 x GPT2Block(             # 12層の Transformer Block
#        (ln_1): LayerNorm((384,), eps=1e-05, elementwise_affine=True) # ln_1 / ln_2	LayerNorm：学習安定化
#        (attn): GPT2Attention(
#          (c_attn): Conv1D(nf=1152, nx=384) # c_attn / c_proj	Conv1D 実装の線形層（入力変換／出力統合）
#          (c_proj): Conv1D(nf=384, nx=384)
#          (attn_dropout): Dropout(p=0.1, inplace=False)  # アテンション後の Dropout
#          (resid_dropout): Dropout(p=0.1, inplace=False) # 残差後の Dropout
#        )
#        (ln_2): LayerNorm((384,), eps=1e-05, elementwise_affine=True)
#        (mlp): GPT2MLP(                                  # mlp	GPT2MLP（位置ごとのフィードフォワードネットワーク）
#          (c_fc): Conv1D(nf=1536, nx=384)
#          (c_proj): Conv1D(nf=384, nx=1536)
#          (act): NewGELUActivation()                     # act	GELU系活性化関数
#          (dropout): Dropout(p=0.1, inplace=False)
#        )
#      )
#    )
#    (ln_f): LayerNorm((384,), eps=1e-05, elementwise_affine=True) # ln_f	最終 LayerNorm
#  )
#  (lm_head): Linear(in_features=384, out_features=135, bias=False) # lm_head	出力：384次元ベクトル → 135語彙確率分布
#)
# GPT2LMHeadModel は Causal LM（文章生成）用のヘッド付きGPT-2
#  内部構造：
#    wte: トークン埋め込み層
#    wpe: 位置埋め込み層
#    h: Transformerブロック（n_layer分）
#    attn: GPT2Attention（マルチヘッドアテンション）
#    mlp: 全結合層 + 活性化
#    ln_1/ln_2: LayerNorm
#    ln_f: 最終正規化
#    lm_head: 出力層（ボキャブラリサイズに変換） Causal LM用の線形層、語彙サイズに変換
# model（例: GPT2LMHeadModel）   公式ドキュメント: GPT2Config
# https://huggingface.co/docs/transformers/main/en/model_doc/gpt2#transformers.GPT2LMHeadModel
# ソースコード:
# https://github.com/huggingface/transformers/blob/main/src/transformers/models/gpt2/modeling_gpt2.py
    
print(f'Load training config.')
# トレーニング設定（TrainingArguments）
# どうやって学習させるかのルール
# 学習ルールを決める。何回学習するか、途中で止めるか
training_args = TrainingArguments(          # training_args → 学習・評価の運用設定
    output_dir=model_output_dir,            # 学習結果保存先 ./model/
    overwrite_output_dir=True,              # 既存ディレクトリがあれば上書き
    num_train_epochs=epoch_num,             # 学習エポック数（全データの繰り返し回数） 30 データを30回繰り返して学習
    per_device_train_batch_size=batch_size, # バッチサイズ（1回の処理にまとめるサンプル数） 512 512文字ずつグループにして学習
    per_device_eval_batch_size=batch_size,  # 評価用バッチサイズ 512
    eval_steps = eval_step,                 # 評価間隔（ステップ数） 定期的に評価・保存 2000 2000グループ学習したらテスト
    save_steps=save_step,                   # チェックポイント保存間隔 6000 6000グループごとに結果を保存
    save_strategy='steps',                  # 保存のタイミング save_steps毎に保存
    evaluation_strategy='steps',
#    eval_strategy='steps',                  # 変更 評価のタイミング eval_steps毎に評価
    prediction_loss_only=True,              # 出力は損失値のみ
### logging_dir=log_dir + time.strftime("%Y%m%d-%H:%M", time.localtime()), # ログ保存先 ./log/
    logging_dir=log_dir + time.strftime("%Y%m%d-%H-%M", time.localtime()), # ログ保存先 ./log/
    seed=random_seed,                       # 乱数シード（再現性） 42
    metric_for_best_model='eval_loss',      # ベストモデル判定指標 load_best_model_at_end=True と組み合わせて、最も評価損失が低いモデルを保存
    load_best_model_at_end=True,            # 学習終了時にベストモデルを読み込む 早期終了による過学習防止
    save_total_limit=1                      # 保存チェックポイントの最大数 最新チェックポイントのみ保存
    )
# エポック数	データセット全体を何回学習するか
# バッチサイズ	一度にモデルに入力するサンプル数
# eval_steps / save_steps	何ステップごとに評価や保存を行うか
# load_best_model_at_end	過学習防止。最良モデルを最後に使用

#print(training_args)
#TrainingArguments(
#_n_gpu=1,                  # 使用GPU数
#accelerator_config={'split_batches': False, 'dispatch_batches': None, 'even_batches': True, 'use_seedable_sampler': True, 'non_blocking': False, 'gradient_accumulation_kwargs': None},
#adafactor=False,
#adam_beta1=0.9,           # AdamW最適化のハイパーパラメータ
#adam_beta2=0.999,         # AdamW最適化のハイパーパラメータ
#adam_epsilon=1e-08,       # AdamW最適化のハイパーパラメータ
#auto_find_batch_size=False,
#batch_eval_metrics=False, # バッチ単位の評価指標を計算しない。
#bf16=False,
#bf16_full_eval=False,
#data_seed=None,
#dataloader_drop_last=False,
#dataloader_num_workers=0,
#dataloader_persistent_workers=False,
#dataloader_pin_memory=True,
#dataloader_prefetch_factor=None,
#ddp_backend=None,
#ddp_broadcast_buffers=None,
#ddp_bucket_cap_mb=None,
#ddp_find_unused_parameters=None,
#ddp_timeout=1800,
#debug=[],
#deepspeed=None,
#disable_tqdm=False,
#dispatch_batches=None,
#do_eval=True,          # 評価を有効化
#do_predict=False,
#do_train=False,        # 学習モードは無効（この設定では推論または評価専用）
#eval_accumulation_steps=None,
#eval_delay=0,
#eval_do_concat_batches=True,
#eval_steps=2000,       # 2000ステップごとに評価を実行
#eval_strategy=IntervalStrategy.STEPS, # 評価間隔の単位（ステップ単位）
#evaluation_strategy=None,
#fp16=False,           # 半精度（FP16）を使わない
#fp16_backend=auto,
#fp16_full_eval=False,
#fp16_opt_level=O1,
#fsdp=[],
#fsdp_config={'min_num_params': 0, 'xla': False, 'xla_fsdp_v2': False, 'xla_fsdp_grad_ckpt': False},
#fsdp_min_num_params=0,
#fsdp_transformer_layer_cls_to_wrap=None,
#full_determinism=False,
#gradient_accumulation_steps=1,
#gradient_checkpointing=False,
#gradient_checkpointing_kwargs=None,
#greater_is_better=False,
#group_by_length=False,
#half_precision_backend=auto,
#hub_always_push=False,
#hub_model_id=None,
#hub_private_repo=False,
#hub_strategy=HubStrategy.EVERY_SAVE,
#hub_token=<HUB_TOKEN>,
#ignore_data_skip=False,
#include_inputs_for_metrics=False,
#include_num_input_tokens_seen=False,
#include_tokens_per_second=False,
#jit_mode_eval=False,
#label_names=None,
#label_smoothing_factor=0.0,
#learning_rate=5e-05,            # 初期学習率
#length_column_name=length,
#load_best_model_at_end=True,    # 最良スコアのモデルを最後に読み込む
#local_rank=0,
#log_level=passive,
#log_level_replica=warning,
#log_on_each_node=True,
#logging_dir=./log/20250720-13:12,
#logging_first_step=False,
#logging_nan_inf_filter=True,
#logging_steps=500,             # ログを500ステップごとに出力
#logging_strategy=IntervalStrategy.STEPS,
#lr_scheduler_kwargs={},
#lr_scheduler_type=SchedulerType.LINEAR, # 学習率スケジューラは線形減衰
#max_grad_norm=1.0,             # 勾配クリッピングの上限（爆発防止）
#max_steps=-1,
#metric_for_best_model=eval_loss, # 最良モデル選択指標は eval_loss（評価損失が小さいほど良い）
#mp_parameters=,
#neftune_noise_alpha=None,
#no_cuda=False,
#num_train_epochs=30,            # 学習エポック数
#optim=OptimizerNames.ADAMW_TORCH,
#optim_args=None,
#optim_target_modules=None,
#output_dir=./model/,           # モデル保存先
#overwrite_output_dir=True,     # 既存の出力ディレクトリを上書き
#past_index=-1,
#per_device_eval_batch_size=512, # 評価時のバッチサイズ（デバイスあたり）
#per_device_train_batch_size=512,# 学習時のバッチサイズ（デバイスあたり）
#prediction_loss_only=True,      # 損失のみ計算（ログ節約）
#push_to_hub=False,
#push_to_hub_model_id=None,
#push_to_hub_organization=None,
#push_to_hub_token=<PUSH_TO_HUB_TOKEN>,
#ray_scope=last,
#remove_unused_columns=True,
#report_to=[],
#restore_callback_states_from_checkpoint=False,
#resume_from_checkpoint=None,
#run_name=./model/,
#save_on_each_node=False,
#save_only_model=False,
#save_safetensors=True,
#save_steps=6000,              # 6000ステップごとにモデル保存
#save_strategy=IntervalStrategy.STEPS, # 保存間隔の単位（ステップ単位）
#save_total_limit=1,           # 保存するチェックポイントは最新1つのみ保持
#seed=42,                      # 乱数シード（再現性確保
#skip_memory_metrics=True,     # メモリ使用量の計測をスキップ（軽量化）
#split_batches=None,
#tf32=None,
#torch_compile=False,
#torch_compile_backend=None,
#torch_compile_mode=None,
#torchdynamo=None,
#tpu_metrics_debug=False,
#tpu_num_cores=None,
#use_cpu=False,
#use_ipex=False,
#use_legacy_prediction_loop=False,
#use_mps_device=False,
#warmup_ratio=0.0,
#warmup_steps=0,            # 学習率ウォームアップなし
#weight_decay=0.0,          # L2正則化なし
#)
# TrainingArguments）    公式ドキュメント:
# https://huggingface.co/docs/transformers/main/en/main_classes/trainer#transformers.TrainingArguments
# ソースコード: __init__ の引数
# https://github.com/huggingface/transformers/blob/main/src/transformers/training_args.py
    
# GPT2Config  GPT-2モデルの設計パラメータ モデル構造を決める GPT-2 モデルの設計図（ハイパーパラメータ）を保持
#  from transformers import GPT2Config
#  クラス：transformers.models.gpt2.configuration_gpt2.GPT2Config
#  役割: モデルの「設計図」（層の数、埋め込み次元、語彙サイズなどの設定）
#  モデルの構造的ハイパーパラメータを保持します（層の数、隠れ層の次元数、語彙サイズ、活性化関数など）。
#  訓練中に変わらない値を定義します。
#  これを渡してモデルを生成すると、その設計図通りの構造のモデルが作られます。
#  設定値を変更すると、既存の事前学習済みモデルのパラメータが使えなくなる場合があります（形が合わなくなるため）
#  モデルの構造やサイズを決定するので、事前学習の有無にかかわらず重要
#  GPT2Config自体はモデルではなく設定の箱だけ
# クラス（設定オブジェクト）	モデルの設計図・ハイパーパラメータ

# model（GPT2LMHeadModel の構造） 学習・推論する本体（ニューラルネットワーク）を作る、GPT-2 の Transformer デコーダ本体
# 実際にニューラルネット計算（推論や損失計算）を行う
# 学習では、モデル本体が入力データを通して**パラメータ（重み）**を更新します。
# 推論では、同じモデル本体がすでに学習済みのパラメータを使って出力を生成します。
# 言い換えると、「学習・推論の本体」とはニューラルネットワークの構造と重みがセットになったもの
#  クラス：transformers.models.gpt2.modeling_gpt2.GPT2LMHeadModel
#  from transformers import GPT2LMHeadModel
#  役割: 実際に使う GPT-2 のモデル本体（学習や推論の対象）
#  GPT2Model に Language Modeling (LM) ヘッド を付けたもの。
#  **Causal Language Modeling（因果言語モデル）**タスク用。
#   → 「次の単語（トークン）を予測する」タイプのモデル
#  GPT2Config を受け取って構造を初期化
#  モデルの中には config が含まれており、model.config でアクセス可能
# config を元に構築される
# クラス（PyTorch nn.Module）	学習・推論する本体（ニューラルネット）
# Trainer がバッチを渡して呼び出す

# training_args（TrainingArguments） Trainer APIに渡す学習設定 どうやって学習するかを決める
#  from transformers import TrainingArguments
#  クラス：transformers.training_args.TrainingArguments
#  役割: 学習時のパラメータや挙動を指定するクラス 学習方法の指定（エポック数、バッチサイズ、評価頻度など）
#  Optimizer のハイパーパラメータ（learning_rate, adam_beta1 など）
#  学習のスケジュール（エポック数、バッチサイズ）
#  ログや保存方法（logging_dir, save_steps）
#  GPU/CPU設定（per_device_train_batch_size, fp16 など）
#  モデルの構造には影響しない（config のような構造的パラメータではない）。
#  どちらかというと「トレーニングの進め方を決める設定書」
#  Trainer に渡して使う
# モデル本体の構造とは無関係
# Trainer や train() 関数がこの値を見て学習を進める
# クラス（設定オブジェクト）	学習方法の設定（Trainer 用）
# Trainer が「どう動くか」を決めるためのパラメータセット

# Trainer
#    DataLoader 作成（バッチ化）
#    モデルの forward → loss 計算
#    backward（勾配計算）
#    optimizer / scheduler 更新
#    評価（必要なら）
#    チェックポイント保存
#    TrainingArguments を参照しながら学習ループを管理 

# 設定オブジェクト
#  「何かの挙動や構造を決めるためのパラメータをまとめた入れ物」
#  実際の計算や処理はしないが、設定値を保持し、それを参照して他の処理が動く
#  データだけを持つ（メソッドはほぼない）

# Trainer API
#  Hugging Face Transformers が提供する学習用の統合インターフェース
#  「モデル学習のための高レベルクラス」で、PyTorch の訓練ループ（forward, loss計算, backward, optimizer step, logging, evaluation）を全部まとめてやってくれる
#  モデルとデータセット、設定（TrainingArguments）を受け取って、自動的に学習・評価を行う
#  分散学習、mixed precision（FP16/FP8）学習、チェックポイント保存、評価ループなどを全部管理

# Hugging Face Transformers 
# 自然言語処理（NLP）や機械学習で広く使われる Pythonライブラリ で、Transformer アーキテクチャをベースとしたモデルの学習・推論・微調整を簡単に行えるようにしたツール
# 最新の Transformer モデル（BERT, GPT-2, GPT-3, RoBERTa, T5, etc.）を簡単に利用できる
# 学習済みモデルの ダウンロード・微調整 (fine-tuning) が容易
# テキスト分類、文章生成、翻訳、要約、質問応答など様々な NLP タスクをサポート


# TrainingArguments（学習条件の設定）
#        ↓
# Trainer（学習ループ管理）
#        ↓
# モデル本体（forward/backward計算）


# Trainerによる学習実行 モデルを学習する！
# Trainer って箱が、全部まとめてやってくれます（学習・テスト・保存）
# 終わったら「最後のいいモデル」をファイルとして保存します
# Trainerが学習ループと評価を管理。Trainer は学習ループ・評価・保存・ログ全体を包括的に管理
# 学習後に最終モデルを指定ディレクトリに保存。
# EarlyStoppingCallback により 評価ロスが改善しなければ自動停止
# 学習を実行	上手くなるまで頑張る
# Trainer は「学習・評価・保存・早期終了・ログ管理」を 自動化 したラッパー
trainer = Trainer(
    model=model,        # 学習するモデル本体。ここでは GPT2LMHeadModel。Trainer がバッチごとに forward() を呼び出して損失計算や勾配更新を行う
    args=training_args, # 学習条件をまとめたオブジェクト (TrainingArguments)。エポック数、バッチサイズ、学習率、保存・評価間隔などを指定。
    data_collator=data_collator, # データをバッチ化する際に呼ばれる関数。DataCollatorForLanguageModeling の場合、トークナイズ済みデータから input_ids や attention_mask をまとめ、必要に応じてマスク学習用にラベルを作成する。
    train_dataset=train_dataset, # 訓練データセット。Dataset オブジェクトで、各サンプルには input_ids や attention_mask が含まれる。
    eval_dataset=eval_dataset,   # 評価データセット。同様に input_ids などを含む。Trainer が定期的に損失を計算してモデルの性能を確認。
    callbacks=[EarlyStoppingCallback(early_stopping_patience=early_stop)], # 早期終了による過学習防止 しばらく学習してもよくならなかったら終了
)                                                                          # 学習中に呼び出す追加機能。ここでは EarlyStoppingCallback を使い、評価損失が改善しなければ学習を早期終了する。early_stopping_patience は「改善が見られない評価ステップの連続回数」。
# EarlyStoppingCallback  
#  評価損失が連続で 3 回改善されない場合に学習を中止
#  過学習防止に有効
#  Trainer が自動的に評価ステップごとに呼び出す
# Trainer クラスは、PyTorch ベースのモデルの学習と評価を簡素化するための高水準 API
# Trainer クラスは、モデル、データセット、トレーニング引数を統合し、学習ループ、評価、チェックポイント保存、Early Stopping などの機能を提供
# 公式　https://huggingface.co/docs/transformers/main_classes/trainer

print(trainer) # <transformers.trainer.Trainer object at 0x000001B9CC2BEBD0>

print(f'*'*30) # ******************************
print(f'Training begin.')

trainer.train()
# ループ処理＋勾配更新＋評価＋早期終了＋チェックポイント保存 をまとめて実行
# 処理の流れ
#  データローダ作成
#    train_dataset をバッチ化
#    data_collator がバッチごとの入力データをまとめる
#  学習ループ
#    各バッチをモデルに渡す → loss 計算
#    勾配を計算（backward） → optimizer がパラメータ更新
#    Dropout や LayerNorm などの処理もモデル内で自動的に適用
#  評価（eval_dataset がある場合）
#    eval_steps ごとに eval_dataset を使い損失を計算
#    EarlyStoppingCallback が評価損失の変化をチェック
#  チェックポイント保存
#    save_strategy に従い、途中でモデルを保存
#    最新の save_total_limit 個だけ保持
# trainer.train() メソッドは、Trainer クラスのインスタンスで呼び出され、モデルの学習を開始する。
# trainer.train() メソッドは、指定されたエポック数だけデータを繰り返し処理し、損失の計算、勾配の更新、評価などを自動で行う
# 学習中は、進捗の表示やログの記録も行われます 
# 公式　https://huggingface.co/docs/transformers/main_classes/trainer#trainer-train    
    
trainer.save_model(model_output_dir+"last-step/")
# 学習終了後、最終モデルを指定ディレクトリに保存
# 保存内容：
#    モデルの重み (pytorch_model.bin または model.safetensors)
#    設定 (config.json)
#    トークナイザー情報（tokenizer.json や vocab.txt）
# これにより、後で推論用にロード可能
# trainer.save_model() メソッドは、学習したモデルを指定したディレクトリに保存します。
# これにより、後でモデルを再利用したり、推論に使用したりすることが可能になります
# 公式　https://huggingface.co/docs/transformers/main_classes/trainer#trainer-save_model
# https://qiita.com/ huggingfaceのTrainerクラスを使えばFineTuningの学習コードがスッキリ書けてめちゃくちゃ便利です
# https://qiita.com/ huggingface/transformersのTrainerの使い方と挙動
# https://zenn.dev/  transformersのtutorialを読んでみた - part3

# ソースコードの順番
# 1. モデルの設定オブジェクト　config = GPT2Config(
# 2. モデル本体  model = GPT2LMHeadModel(config)  
# 3. データセット読み込み（例: wikitext）  dataset = load_dataset("wikitext", "wikitext-2-raw-v1")
#                   train_dataset = dataset["train"] eval_dataset = dataset["validation"]
# 4. 学習条件（TrainingArguments） training_args = TrainingArguments(
# 5. Trainer（学習ループの司令塔） trainer = Trainer(
# 6. 学習実行  trainer.train()

 
# 学習と推論の流れ
# 学習時
#    トークン化した文章（ID列）をモデルに入力
#    モデル内部の層で順伝播（forward pass）
#    出力と正解ラベルを比較して損失（loss）を計算
#    誤差逆伝播でパラメータ更新（model の重みが変わる）
# 推論時
#    学習済みの model に入力を渡す
#    出力（次のトークン確率分布）を得る
#    サンプリングやgreedy法などで文章生成



print(f'Model saved in {model_output_dir+"last-step/"}') # Model saved in ./model/last-step/
print(f'*'*30) # ******************************
print(f'Training done.')