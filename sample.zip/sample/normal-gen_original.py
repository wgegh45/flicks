from transformers import (
    GPT2LMHeadModel
)
import time
import threading
import torch
from tokenizer import CharTokenizer
import argparse
import os


MAX_LEN = 32    # It should be equal to input size of model.
                # モデルの入力サイズと同じでなければならない。
       

# gen_sample 関数など複数の処理を並列実行し、それぞれの戻り値（結果）を後から取得するために使用
# スレッドが生きているか (is_alive()) や終了時にスレッドをリストから削除 (threads.pop(t)) したい場合にも、このクラスが使われる
# Python の標準ライブラリ threading.Thread を拡張したクラスで、スレッドで処理を走らせたあとに戻り値を受け取れるようにしたもの
# threading.Thread を継承して、自作のスレッドクラスを定義
# スレッドが関数の戻り値を返せるようにする」ための拡張
class ThreadBase(threading.Thread):
    """ overload threading, so that it can return values """
    """値を返すことができるように過負荷スレッド"""
    def __init__(self, target=None, args=()): # target に実行したい関数、args にその関数へ渡す引数タプルをセット
        super().__init__()
        self.func = target
        self.args = args
 
    # 通常の threading.Thread の run は target(*args) を呼ぶだけで戻り値を保持しない
    def run(self): # スレッドが start() されたときに自動的に呼ばれるメソッド
        self.result = self.func(*self.args) # self.result に代入して保持するようにしている
 
    # スレッドの処理が終わった後に、結果を取り出すためのメソッド
    # self.result がまだ存在しない場合（例: スレッドがまだ終わっていない等）は Exception が発生するので、その場合は None を返す
    def get_result(self):
        try:
            return self.result
        except Exception as e:
            print(e)
            return None



# 1つのGPUごとにパスワードを生成
# 指定された GPU で GPT2 モデルをロードし、空文字列を入力にして、確率的に複数（例: 5000個）の文字列を生成し、それをテキストに変換する」関数
def gen_sample(test_model_path, tokenizer, GEN_BATCH_SIZE, GPU_ID): # ./model/last-step/ 5000 0

    # 学習済みGPT2モデルを指定されたパスから読み込む
    # モデルロード → すでに学習済みの GPT2 モデルをディスクからロード
    model = GPT2LMHeadModel.from_pretrained(test_model_path)        # ./model/last-step/
    
    # 使用するGPUを文字列で指定（例："cuda:0"）
    # GPU指定 → "cuda:0" や "cuda:1" のように文字列でどのGPUを使うか決める。
    device = "cuda:"+str(GPU_ID)
    
    # モデルを指定GPUに転送
    # モデルをGPUへ移動 → 生成を CPU ではなく GPU 上で計算させる。
    model.to(device)
    print(device) #  cuda:0 cuda:0 ・・・
    print(model)  # train.pyの出力時と同じ
    '''    
    GPT2LMHeadModel(
        (transformer): GPT2Model(
            (wte): Embedding(135, 384)
            (wpe): Embedding(32, 384)
            (drop): Dropout(p=0.1, inplace=False)
            (h): ModuleList(
                (0-11): 12 x GPT2Block(
                    (ln_1): LayerNorm((384,), eps=1e-05, elementwise_affine=True)
                    (attn): GPT2Attention(
                        (c_attn): Conv1D()
                        (c_proj): Conv1D()
                        (attn_dropout): Dropout(p=0.1, inplace=False)
                        (resid_dropout): Dropout(p=0.1, inplace=False)
                        )
                    (ln_2): LayerNorm((384,), eps=1e-05, elementwise_affine=True)
                    (mlp): GPT2MLP(
                        (c_fc): Conv1D()
                        (c_proj): Conv1D()
                        (act): NewGELUActivation()
                        (dropout): Dropout(p=0.1, inplace=False)
                        )
                    )
                )
            (ln_f): LayerNorm((384,), eps=1e-05, elementwise_affine=True)
            )
        (lm_head): Linear(in_features=384, out_features=135, bias=False)
        )
    '''    
    
    # 入力文を設定（ここでは空文字列）
    # 入力文字列 → 今回は空文字列（=プロンプトなしで生成開始）。
    inputs = ""
    
    # トークナイザーで入力文字列を数値化（出力は１次元）
    # encode_forgen はこのリポジトリ特有の拡張関数で、入力を token ID 列に変換
    # 数値化 → モデルが扱えるように、文字列をトークンIDに変換。
    tokenizer_forgen_result = tokenizer.encode_forgen(inputs)
    print(tokenizer_forgen_result) # tensor([0])
    
    # 生成したパスワードを格納する空の集合を用意（重複排除のため set() を使用）
    # 集合（set）用意 → パスワード生成タスクなので、同じパスワードを除外するために set を用意
    passwords = set()
    print(passwords) # set()
    
    # GPT2モデルを使ってパスワードを生成
    # 入力が max_length より短い場合 → pad_token_id を埋めてバッチ内の長さを揃える
    # 例: max_length=32, 入力長=5 の場合 → [tok1, tok2, tok3, tok4, tok5, pad, pad, ..., pad] (長さ32)
    outputs = model.generate(
        input_ids= tokenizer_forgen_result.view([1,-1]).to(device), # 入力を[バッチ=1, トークン列]形状に変換しGPUへ  
                                                                    # view([1,-1]) → 入力を「1文」として形を整える バッチ次元を追加して [1, seq_len] にする                                
                                                                    # .to(device) → GPU に送る
        pad_token_id=tokenizer.pad_token_id, # パディングに使うトークンを指定(pad_token_id → 途中で長さが足りなければパディング)
        max_length=MAX_LEN, # 最大長 32  生成する最大トークン数　列の最大トークン長 EOS を引けば短く終わる
        do_sample=True,     # 貪欲法greedyではなく確率分布からの多様サンプリング。同一入力でも毎回違う列になり得る ランダム性を持たせる
        num_return_sequences=GEN_BATCH_SIZE, # 一度に生成する数 5000個  複数サンプルを一度に生成　1回の呼び出しで N 本の列をまとめて返す
        )
    print(outputs)
    # tensor([[  0,  23,   1,  95,  97,   0,  94,  85,  81,   2,   4,   4,   4,   4,   4,   4,   4],
    #         [  0,  22,   1, 119,  77,  96,  85,  81,  94,   2,   4,   4,   4,   4,   4,   4,   4],
    #　　　　　　　　・・・
    #         [  0,  22,   1,  89,  91,  52,  20,  98,  81,  81,  94,   2,   4,   4,   4,   4,   4]], device='cuda:0')
    
    # 生成されたトークン列を文字列に変換（複数まとめてデコード）
    # デコード → vocab.jsonで、モデルが返したトークン列（IDのリスト）をまとめて人間が読める文字列に変換
    outputs = tokenizer.batch_decode(outputs)
    print(outputs)
    # ['L6 surie', 'L7 ;atier', ' fespNeS11', 'L9 mes(ssu$', 'L6 lollelS7', 'L6 an[her', 'L6 aL6oulL5', 'L6 sqcL6N7l', 'L6 ater%er', 'L6 aN9345L|', 'L6 andxie', 'L8 rfpL9KcuL8', 'L7 t8`u^L12P', 'L6 $/oc?t', '( a2ichedN7', 'L6 an8;eW', 'L6 Wodmo(', 'L9 c`S355^ico', 'L8 FaubJpr', 'L7 panisw^', 'L7 rf^bla', 'L6 WeroN6a', 'L6 motteN7', 'z c wiiy', 'L7 chelou', 'L96boB/Umoo errL1', 'L6 mL53N11lN8', 'L6 dL1dand', 'L6 sL4eL10ic0^', 'L6g alJoN2', 'L7 ie_N6isN11', 'L7 aneloC', 'L6 sN11bL5Ne', 'L6 wS4%hoy', '( 1L4ekN63', 'L8 cN1_t8]he<UNK>9', 'L7L11kolery', 'L7 hucL8sbn', 'L6 bangey', 'L7 ac%BL4ia', 'L7 >pC(oq7', 'L8 lochermer', '& 1234569', 'L7 dutktS4a', 'N6 12311', 'L6 vetyoo', 'U sssshw', 'u Cagean', 'L6 angerr3', 'L7 moBL9veer']
    # !next
    
    for output in outputs:
        passwords.add(output)

    return [*passwords,]




'''
文字列をトークンIDに変換
入力: "password"
トークン: ["pass", "word"]
ID: [1234, 5678]

生成処理の流れ
model.generate() 内部は 逐次生成 (autoregressive decoding) を行う。
 初期入力: [1, seq_len] のテンソル
 生成ループ:
  1 現在の系列をモデルに入力する
    → 出力ロジット（サイズ: [batch, vocab_size]）が得られる（最後の位置のトークンに対する予測）。
  2 softmax を適用し、語彙ごとの確率分布に変換。
    P(t)=exp⁡(logit t) / ∑j exp⁡(logit j)
  3 サンプリング戦略
     do_sample=True → multinomial sampling で確率分布からランダムに 1 トークンを選択。
     do_sample=False → greedy (最尤トークンを選ぶ)。
  4 選ばれたトークンを系列に追加。
  5 新しい系列を次ステップの入力として再びモデルへ。
  6 これを max_length に達するか EOS が出るまで繰り返す。

[1, seq_len] の 1 は、入力文の個数が1つという意味
ThreadBase の batch_size（args.batch_size）とは 無関係
入力は常に [1, seq_len] で1件ずつ処理するが、出力は batch_size に応じて複数得られる
view([1, -1]で強制的に [1, seq_len] (入力文の個数が1)に reshape している
1つのプロンプト（入力文字列）を「1バッチ」として扱うように固定している

入力を [バッチ=1, トークン列] 形状にする  [1, seq_len]（バッチ=1）に整形する理由
Transformers は input_ids を (batch_size, sequence_length) 形状で受け取る
1本の列だけでも「バッチ次元」が必要なので、tokenizer_forgen_result.view([1, -1]) の処理で、先頭に 1 を足して [1, seq_len] にする
こうして GPU 上で1バッチとして扱えるようになる
PyTorch のモデル入力は 2次元テンソル が基本です。
次元0: バッチサイズ（例: 同時に複数文を処理する数）
次元1: トークンの長さ（系列長）
例えば "password" をトークナイズして [1234, 5678] になった場合、
view([1, -1]) を使うと次のようになります。
tensor([[1234, 5678]])
これは バッチサイズ = 1、系列長 = 2 の形。
こうすることで、モデルが「1文だけどバッチ形式で処理する」と解釈できるようになる

トークナイズ → 整形 → パディング → max_length の関係
トークナイズ：テキスト→整数ID列（各文字が語彙表の1IDに直対応）1文字=1トークン

do_sample=True かつ num_beams=1（デフォルト）
各ステップでモデルのロジット→softmaxで確率化→多項分布サンプリング（multinomial sampling）で次トークンを1つ引く、を逐次繰り返す

生成の停止条件
EOSトークン（eos_token_id）がサンプリングされる。→ そのシーケンスは即終了。
長さ上限（ここでは max_length）に達する。
生成のどのステップかで確率的に EOS が選ばれた場合、その系列はそこで終了（デコード停止）。
ただし:PagPassGPT の場合、明示的に EOS を設定していない可能性があり、多くの場合 max_length で切る動作になる

max_length は プロンプト長＋生成長の合計の上限を意味する
入力が 5 トークンで max_length=32 の場合、追加で生成される長さは最大 27 トークン
出力系列は最終的に [prompt_tokens + generated_tokens] になる

1 トークナイズ
  例: "abc" → [id_a, id_b, id_c]
2 テンソル化
  PyTorch tensor に変換し、モデルが扱いやすいよう shape を [seq_len] にする。
3 バッチ次元を追加
  shape を [1, seq_len] に変換（バッチサイズ=1）。
  
LayerNorm
Transformer 内で用いられる Layer Normalization の安定化パラメータ

系列長（最大ポジション数）
このモデルが扱える入力系列の最大長（トークン数）。
トークナイズ後のトークン列が 32 を超える場合は切り捨てるかエラーになる。
つまり、このモデルは「最大32文字」の入力しか扱えない。

'''


def gen_parallel(vocab_file, batch_size, test_model_path, N, gen_passwords_path, num_gpus, gpu_index): #  ./tokenizer/vocab.json 5000 ./model/last-step/ 1000000 ./generate/ 1 0
    print(f'Load tokenizer.')
    # 訓練train.pyと同じ  char_tokenizer.pyの__init__関数へ
    # トークナイザーの定義（1文字単位で文章を分割して文字ごとにID（インデックス）を割り当てる（<BOS>→0、a→5・・・）ことで、パスワードを「1文字ごとの数字」に変えて学習できるようになる）
    tokenizer = CharTokenizer(vocab_file=vocab_file, # ./tokenizer/vocab.json
                              bos_token="<BOS>",
                              eos_token="<EOS>",
                              sep_token="<SEP>",
                              unk_token="<UNK>",
                              pad_token="<PAD>"
                              )
#    print(tokenizer)
#CharTokenizer(name_or_path='', vocab_size=135, model_max_length=1000000000000000019884624838656, is_fast=False, padding_side='right', truncation_side='right', special_tokens={'bos_token': '<BOS>', 'eos_token': '<EOS>', 'unk_token': '<UNK>', 'sep_token': '<SEP>', 'pad_token': '<PAD>'}, clean_up_tokenization_spaces=True),  added_tokens_decoder={
#	0: AddedToken("<BOS>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#	1: AddedToken("<SEP>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#	2: AddedToken("<EOS>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#	3: AddedToken("<UNK>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#	4: AddedToken("<PAD>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#}        
    # padding_side='left' 短い文章を 左側に <PAD> を挿入してバッチの長さを揃える設定
    # 右側にパディングがあると、最後に来るのはパディングのため、次に生成されるべきトークンを選ぶステップで、モデルがその“パディング”を延々と出力する可能性があるためleftにする
    # 右パディングの場合、モデルの最後に pad トークンが配置され、それが次の生成ステップの元入力になると、モデルは「次も pad を出すべき」と予測し続けることがある
    tokenizer.padding_side = "left"
#    print(tokenizer)
#CharTokenizer(name_or_path='', vocab_size=135, model_max_length=1000000000000000019884624838656, is_fast=False, padding_side='left', truncation_side='right', special_tokens={'bos_token': '<BOS>', 'eos_token': '<EOS>', 'unk_token': '<UNK>', 'sep_token': '<SEP>', 'pad_token': '<PAD>'}, clean_up_tokenization_spaces=True),  added_tokens_decoder={
#	0: AddedToken("<BOS>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#	1: AddedToken("<SEP>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#	2: AddedToken("<EOS>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#	3: AddedToken("<UNK>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#	4: AddedToken("<PAD>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#}    
       
    # mulit gpu parallel
    if not torch.cuda.is_available():
        print('ERROR! GPU not found!')
    else:
        total_start = time.time() # 学習の開始時刻
        threads = {}         # スレッドオブジェクトをキー、GPU番号を値とする辞書
        total_passwords = [] # 生成したすべてのパスワード

        total_round = N//batch_size # 1000000/5000=200
        print('*'*30) # ******************************
        print(f'Generation begin.')
        print('Total generation needs {} batchs.'.format(total_round)) # Total generation needs 200 batchs.

        i = 0
        print(len(threads)) # 0
        
        while(i < total_round or len(threads) > 0 ): # i < 200 or 0 > 0
        
            if len(threads) == 0: # まだスレッドが立ち上がっていない（threadsに何もない状態ならforループ実行）
            
                for gpu_id in range(num_gpus): # range(num_gpus)=1　GPUごとに1スレッドを立ち上げる準備
                    if i < total_round: # i < 200
                        # thredBaseクラスの__init__へ
                        # スレッドオブジェクトtを返す（スレッド内でgen_sample関数を実行するため）
                        # まだ .start() していないので、この時点では実行は始まっていない
                        # ThreadBaseはthreading.Thread を継承した独自クラス
                        # ThreadBaseは複数GPUで gen_sample を並列実行し、その結果を回収するため に使われる
                        # ThreadBaseの使われるタイミングは 生成処理の開始時（並列実行の起動時） と 生成結果の収集時（join後の get_result 呼び出し時）
                        # args=(...) → gen_sample に渡す引数
                        #   test_model_path → 学習済みモデルのパス
                        #   tokenizer → トークナイザー
                        #   batch_size → バッチサイズ
                        #   gpu_id + gpu_index → 使うGPU番号
                        # ThreadBase(threading.Thread) を使ってスレッドを作成
                        # GPUごとに gen_sample(...) を別スレッドで起動→join して結果を集約する
                        t=ThreadBase(target=gen_sample, args=(test_model_path, tokenizer, batch_size, gpu_id+gpu_index)) # ./model/last-step/ 5000 0+0
                        print(t) # <ThreadBase(Thread-6, initial)>  <ThreadBase(Thread-7, initial)>
                      
                        # スレッドを開始（gen_sample関数が並列に実行される）
                        t.start()
                        
                        threads[t] = i # threads 辞書に {キー（スレッドオブジェクト）t: gpu_id} のように登録
                        i += 1
                        
                        # Thread-6:スレッドの名前  stopped:すでに終了  29160:OS 内部での ID
                        print(threads) # {<ThreadBase(Thread-6, started 32296)>: 0}　{<ThreadBase(Thread-6, started 20344)>: 1}　Threadの番号は実行ごとに変わる

                        print(i)       # 1 2
            
            # check whether some threads have finished.
            # いくつかのスレッドが終了したかどうかを確認してください。
            temp_threads = threads.copy() # threads 辞書のコピーを作る(threads を直接ループ中に変更するとエラーになるので、コピーを使っている) {ThreadBase:0}
            print(temp_threads)        # {<ThreadBase(Thread-6, started 29160)>: 0} {<ThreadBase(Thread-7, started 52328)>: 1}
            for t in temp_threads:     # temp_threads のキー（スレッドオブジェクト）を1つずつ取り出す
                                       # ループ1回目 → t = <ThreadBase(Thread-6, stopped 29160)>
                                       # ループ2回目 → t = <ThreadBase(Thread-7, stopped 52328)>
                                       
                t.join() # 該当スレッドの終了を待つ(すでに stopped なら即座に返る)実行が終わるまで待機
                print(t) # <ThreadBase(Thread-6, stopped 29160)>  <ThreadBase(Thread-7, stopped 52328)>
                         # Thread-6 → GPU0 担当、プロセスID 29160
                         # Thread-7 → GPU1 担当、プロセスID 52328
                         # stopped なので処理は終了している
                         
                if not t.is_alive(): # スレッドが終了していたら下の処理を実行
                    new_passwords = t.get_result() # ThreadBaseクラスへのget_result
                    print(new_passwords) # ['L7 mismheC', '', 'L8 ckeriesm', ・・・, 'L7 dsater']
                    new_num = len(new_passwords) # 50 batch_size=5000のとき4883
                    total_passwords += new_passwords # 生成したすべてのパスワードに追加
                    print('[{}/{}] generated {}.'.format(temp_threads[t]+1, total_round, new_num)) # [1/200] generated 50.　　　[1/2] generated 4883.
                                                                                                   # [200/200] generated 50.  [2/2] generated 4882.
                    threads.pop(t) # 元の threads 辞書からこのスレッドを削除(pop(t) → キー t に対応する要素)
                                   # スレッドが終わったので管理リストから除去 → threads は空になる
                                   
         # 生成したパスワードの代入（set関数で重複は排除される）        
        total_passwords = set(total_passwords) # 4883+4882=9765から9708個に減る

        gen_passwords_path = gen_passwords_path + 'Normal-GEN' + '.txt' # ./generate/1000000/Normal-GEN.ｔｘｔ
        
        # ./generate/1000000/Normal-GEN.ｔｘｔを書き込み用に開く
        f_gen = open(gen_passwords_path, 'w', encoding='utf-8', errors='ignore')

        # 生成したパスワードを./generate/1000000/Normal-GEN.ｔｘｔに1パスワードずつ書き込む
        for password in total_passwords:
            f_gen.write(password+'\n') # パスワードは「L8 chN8reter」

        total_end = time.time()             # 学習の終了時刻
        total_time = total_end-total_start  # 学習にかかった時間
        
        print('Generation file saved in: {}'.format(gen_passwords_path)) # Generation file saved in: ./generate/10000/Normal-GEN.txt
        print('Generation done.')
        print('*'*30)                           # ******************************
        print('Use time:{}'.format(total_time)) # Use time:153.1664080619812
        

if __name__ == '__main__':
    
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", help="directory of pagpassgpt", type=str, required=True)
    parser.add_argument("--vocabfile_path", help="path of vocab file", type=str, default='./tokenizer/vocab.json')
    parser.add_argument("--output_path", help="path of output file path", type=str, required=True)
    parser.add_argument("--generate_num", help="total guessing number", default=1000000, type=int)
    parser.add_argument("--batch_size", help="generate batch size", default=5000, type=int)
    parser.add_argument("--gpu_num", help="gpu num", default=1, type=int)
    parser.add_argument("--gpu_index", help="Starting GPU index", default=0, type=int)
    args = parser.parse_args()

    model_path = args.model_path     # ./model/last-step/
    vocab_file = args.vocabfile_path # ./tokenizer/vocab.json
    output_path = args.output_path   # ./generate/

    n = args.generate_num            # 1000000 default
    batch_size = args.batch_size     # 5000    default
    num_gpus = args.gpu_num          # 1       default
    gpu_index = args.gpu_index       # 0       default

    output_path = output_path + str(n) + '/'  # ./generate/n/
    folder = os.path.exists(output_path)      # フォルダがあるとき、True
    if not folder:                            # フォルダがないとき、フォルダを作成
        os.makedirs(output_path)
    
    # gen_parallel関数へ
    gen_parallel(vocab_file, batch_size, model_path, n, output_path, num_gpus, gpu_index) #  ./tokenizer/vocab.json 5000 ./model/last-step/ 1000000 ./generate/ 1 0   