# This file aims to generate vocab file with special pattern tokens.
# このファイルは特殊なパターントークンを持つvocabファイルを生成することを目的としています。

import json
from collections import OrderedDict
import argparse
import os

parser = argparse.ArgumentParser()
parser.add_argument("--save_path", help="save path of vocab file", type=str, default='./tokenizer/vocab.json')
parser.add_argument("--max_len", help="max length of password in datasets", default=12, type=int)
args = parser.parse_args()
#print(args)   Namespace(save_path='./tokenizer/vocab.json', max_len=12)


if not os.path.isfile(args.save_path): # ./tokenizer/vocab.jsonがあると処理されない
    # ASCII
    Number = [(48, 57)] # '0'〜'9'
    Letter = [(65, 90), (97, 122)] # 'A'〜'Z', 'a'〜'z'
    Special_char = [(33, 47), (58, 64), (91, 96), (123, 126)] # !"#$%&'()*+,-./  :;<=>?@   `[]^_``  {|}~

    chars = [Number, Letter, Special_char]
  # print(chars) [[(48, 57)], [(65, 90), (97, 122)], [(33, 47), (58, 64), (91, 96), (123, 126)]]

    Special_token = ["<BOS>", "<SEP>", "<EOS>", "<UNK>", "<PAD>"]

    vocab_dict = OrderedDict()
    print(vocab_dict) # OrderedDict()
    
    index = 0

    for token in Special_token: # ['<BOS>', '<SEP>', '<EOS>', '<UNK>', '<PAD>']
        print(token) # <BOS> <SEP> <EOS> <UNK> <PAD>
        vocab_dict[token] = index
        index += 1 # 1 2 3 4 5
      # print(vocap_dict) OrderedDict({'<BOS>': 0, '<SEP>': 1, '<EOS>': 2, '<UNK>': 3, '<PAD>': 4})
 
    for char_type in ['N', 'L', 'S']: # N L S
        for length in range(args.max_len, 0, -1): # args.max_len=12  12 11 10 ・・・ 1
            print(char_type+str(length)) # N12 N11 ・・・ N1 L12 ・・・ L1 S12 ・・・・ S1
            vocab_dict[char_type+str(length)] = index # [N12]=5 [N11]=6 ・・・ [S1]=40
            index += 1 # 6 ・・・ 41

    for char_type in chars: # [Number, Letter, Special_char]
        for turple in char_type: # ['N', 'L', 'S']
            for i in range(turple[0], turple[1]+1): # i = 48 49
                print(char_type) # [(48, 57)]  [(65, 90), (97, 122)] [(33, 47), (58, 64), (91, 96), (123, 126)]
                print(turple)    # (48, 57)    (65, 90) (97, 122)  (33, 47) (58, 64) (91, 96) (123, 126)
                print(range(turple[0], turple[1]+1)) # range(48, 58) range(65, 91) range(97, 123) range(33, 48) range(58, 65) range(91, 97) range(123, 127)
                print(chr(i))    # 0 1 2 ・・・ 9 A B ・・・ Z a ・・・ z ! ・・・ ~
                vocab_dict[chr(i)] = index # [0]=41 [1]=42 ・・・ [9]=50 [A]=51 ・・・ [Z]=76 [a]=77 ・・・ [z]=102 [!]=103 ・・・
                index += 1       # 42 43 ・・・ 50 51 ・・・ 76 77  ・・・ 102 103 ・・・ 134

    json_str = json.dumps(vocab_dict, indent=4)
    print(json_str) # { "<BOS>": 0, "<SEP>": 1, ・・・ "~": 134 }
    
    # ./tokenizer/vocab.jsonを書き込み用に開く
    with open(args.save_path, 'w') as json_file:
        json_file.write(json_str) # { "<BOS>": 0, "<SEP>": 1, ・・・ "~": 134 }
