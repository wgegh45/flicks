"""
This file aims to implement data cleaning:
このファイルは、データのクリーニングを実装することを目的としています。

    We retained passwords with lengths ranging between 4 and 12 characters.
    We removed duplicate passwords.
    We removed the passwords containing Non-ASCII characters and invisible ASCII characters.
    4〜12文字の範囲の長さのパスワードを保持しました。 
    重複したパスワードを削除しました。 
    ASCII以外の文字と目に見えないASCII文字を含むパスワードを削除しました。
"""


import argparse


# 4-12以外の長さとASCII以外の文字のパスワードを除外
def filter_password(password):
    if len(password) < 4 or len(password) > 12: # 4-12以外の長さのとき処理しない
        return False
    for ch in password: # 1文字ずつ調べる  ord(char)は文字をASCIIコードに変換
        if ord(ch) > 126 or ord(ch) <= 32: # ASCII以外の文字とのとき除外
            return False
    return True



# rockyou.txtからrockyou-cleaned.txtを作る
def preprocess(password_path, output_path): # ./dataset/rockyou.txt  ./dataset/rockyou-cleaned.txt
    # rockyou.txtを読み込み用に開き、rockyou-cleaned.txtを書き込み用に開く
    f = open(password_path, 'r', encoding='utf-8', errors='ignore')
    f_out = open(output_path, 'w', encoding='utf-8', errors='ignore')

    lines = f.readlines() # すべて読み込む(ファイルが\r\nでも読み込み時に\rは消される)
#    print(lines) # ['123456\n', '123456\n', ・・・, 'killer\n']
    lines = set(lines) # 重複を除去（順番は保持されないので変わる）
#    print(lines) # {'steven\n', 'qwerty\n', ・・・, '1234567\n'}
    total_num = 0 # 重複を除いたパスワードの数（空行も1つに数えられる）
    valid_num = 0 # 有効なパスワードの数
    
    # パスワード1つごとに処理を行う
    for line in lines:
        if not line:
            continue # 最終行のとき
        else:
            total_num += 1 # 重複を除いたパスワードの数（空行も1つに数えられる）のカウント
            
            # filter_password関数へ(4-12以外の長さとASCII以外の文字のパスワードを除外)
            if filter_password(line[:-1]): # -1は改行\nを除くため
                valid_num += 1    # 有効なパスワードの数のカウント
                f_out.write(line) # ./dataset/rockyou-cleaned.txtに書き込む
                
    print('Total num={}'.format(total_num))  # 143　14344328　パスワードの総数
    print('Retain num={}'.format(valid_num)) # 143　13265314　有効なパスワードの数
    print('Retain rate:{}'.format(valid_num/total_num)) # 1.0　0.9247776542756133　143/143
    
    f.close()
    f_out.close()



# python clean_dataset.py  --dataset_path=./dataset/rockyou.txt  --output_path=./dataset/rockyou-cleaned.txt
# rockyou.txtからrockyou-cleaned.txt(4-12以外の長さとASCII以外の文字を含むパスワードを除外)を作る
if __name__ == '__main__': # Pythonスクリプトを「直接実行」したとき（import scriptのようにモジュールとしてインポートしときは実行しない）

    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_path", help="path of original dataset", type=str, required=True)
    parser.add_argument("--output_path", help="path of cleaned dataset", type=str, required=True)
    args = parser.parse_args()
    print(args) # Namespace(dataset_path='./dataset/rockyou.txt', output_path='./dataset/rockyou-cleaned.txt')

    print(f'Clean dataset begin.')
    print(args.dataset_path) # ./dataset/rockyou.txt
    print(args.output_path)  # ./dataset/rockyou-cleaned.txt
    
    # preprocess関数へ
    preprocess(args.dataset_path, args.output_path) # ./dataset/rockyou.txt ./dataset/rockyou-cleaned.txt
    
    print(f'Clean dataset done.')
    