"""
This file aims to split whole dataset into training set and test set:
このファイルは、データセット全体をトレーニングセットとテストセットに分割することを目的としています。
    Training set will be used in training and will be split again (for validation).
    Test set will be used in evaluation.
    トレーニングセットはトレーニングに使用され、検証のために再度分割されます。
　　　テストセットは評価に使用されます。
"""

import random
import argparse


def split_train_test(file_path, ratio, train_path, test_path):
    # rockyou-cleaned.txtを読み込み用に開く
    with open(file_path, 'r') as f:
        lines = f.readlines()
        
    print('Shuffling passwords.')
    # rockyou-cleaned.txtをシャッフルする
    random.shuffle(lines)
    f.close()

    # パスワードの総数×0.8
    split = int(len(lines) * ratio)

    # 80%分のパスワードをrockyou-cleaned-Train.txtに書き込む
    with open(train_path, 'w') as f:
        print('Saving 80% ({}) of dataset for training in {}'.format(split, train_path)) # Saving 80% (114) of dataset for training in ./dataset/rockyou-cleaned-Train.txt
        f.write(''.join(lines[0:split]))
    f.close()

    # 20%分のパスワードをrockyou-cleaned-Test.txtに書き込む
    with open(test_path, 'w') as f:
        print('Saving 20% ({}) of dataset for test in {}'.format(len(lines) - split, test_path)) # Saving 20% (29) of dataset for test in ./dataset/rockyou-cleaned-Test.txt
        f.write(''.join(lines[split:]))
    f.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_path", help="path of cleaned dataset", type=str, required=True)
    parser.add_argument("--train_path", help="save path of training set after split", type=str, required=True)
    parser.add_argument("--test_path", help="save path of test set after split", type=str, required=True)
    parser.add_argument("--ratio", help="split ratio", type=float, default=0.8)
    args = parser.parse_args()
    print(args) # Namespace(dataset_path='./dataset/rockyou-cleaned.txt', train_path='./dataset/rockyou-cleaned-Train.txt', test_path='./dataset/rockyou-cleaned-Test.txt', ratio=0.8)

    print(f'Split begin.')
    
    # split_train_test関数へ
    print(args.dataset_path) # ./dataset/rockyou-cleaned.txt
    print(args.ratio)        # 0.8
    print(args.train_path)   # ./dataset/rockyou-cleaned-Train.txt
    print(args.test_path)    # ./dataset/rockyou-cleaned-Test.txt
    split_train_test(args.dataset_path, args.ratio, args.train_path, args.test_path)
    
    print(f'Split done.')