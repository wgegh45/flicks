"""
This file aims to process the input passwords to the rule as follows for convience to train:
このファイルは、トレーニングの便宜上、入力パスワードを次のようなルールに従って処理することを目的としています。    
    pattern <SEP> password

"""


import argparse

# passwordのpassword1から['L8', 'S1']のような文字列を作る
def get_pattern(password:str):
    result = []
#    password = 'aA1!aA1!'
    current_type = None
    current_length = 0 # 現在の文字種が連続する数（L:英字、N：数字、S:数字）
    
    for char in password: # char = "password1"のとき
        if char.isalpha():
            if current_type == 'L':
                current_length += 1
            else:
                if current_type: # current_typeがLNSのいずれかのとき
                    result.append(current_type + str(current_length))
                current_type = 'L'
                current_length = 1
        elif char.isdigit():
            if current_type == 'N':
                current_length += 1
            else:
                if current_type: # current_typeがLNSのいずれかのとき
                    result.append(current_type + str(current_length))
                current_type = 'N'
                current_length = 1
        else:
            if current_type == 'S':
                current_length += 1
            else:
                if current_type: # current_typeがLNSのいずれかのとき
                    result.append(current_type + str(current_length))
                current_type = 'S'
                current_length = 1
        print(current_type)   # L L L L L L L L S
        print(current_length) # 1 2 3 4 5 6 7 8 1
    
    if current_type: # current_typeがLNSのいずれかのとき
        result.append(current_type + str(current_length)) # L 8, S 1
        
    print(result) # ['L8', 'S1']
    return result



if __name__ == '__main__':
    
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_path", help="path of training dataset after split", type=str, required=True)
    parser.add_argument("--output_path", help="path of output dataset (ready for training)", type=str, required=True)
    args = parser.parse_args()
    print(args) # Namespace(dataset_path='./dataset/rockyou-cleaned-Train.txt', output_path='./dataset/rockyou-cleaned-Train-ready.txt')
    
    input_dataset = args.dataset_path # ./dataset/rockyou-cleaned-Train.txt
    output_dataset = args.output_path # ./dataset/rockyou-cleaned-Train-ready.txt
    
    # rockyou-cleaned-Train.txtと読み込み用、rockyou-cleaned-Train-ready.txtを書き込み用に開く
    f_in = open(input_dataset, 'r', encoding='utf-8', errors='ignore')
    f_out = open(output_dataset, 'w', encoding='utf-8', errors='ignore')

    # rockyou-cleaned-Train.txtのパスワードを代入する
    lines = f_in.readlines()

    # 1つのパスワードごとに処理
    for line in lines:
        password = line[:-1] # パスワード代入　-1は改行\nを除くため
#        print(password)
        
        # get_pattern関数へ
        prompt = ' '.join(get_pattern(password)) # "password1"のとき、L8 S1
        print(prompt) # L8 S1
        
        new_line = prompt + ' <SEP> ' + ' '.join(list(password)) + '\n' # L8 N1 <SEP> p a s s w o r d 1
        f_out.write(new_line) # rockyou-cleaned-Train-ready.txtに書き込む
