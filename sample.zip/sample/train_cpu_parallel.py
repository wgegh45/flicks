# This file aims to train a PagPassGPT.
# このファイルは、PagPassGPT をトレーニングすることを目的としています。

from tokenizer.char_tokenizer import CharTokenizer
from transformers import DataCollatorForLanguageModeling

###from datasets import load_dataset
#from datasets import Dataset  ### 方法0　メモリエラーになる

from transformers import GPT2Config
from transformers import GPT2LMHeadModel
from transformers import Trainer, TrainingArguments, EarlyStoppingCallback
import time
import argparse




parser = argparse.ArgumentParser()

# file path parameter setting
# ファイルパスパラメータ設定
parser.add_argument("--dataset_path", help="path of preprocessed train dataset", type=str, required=True)
parser.add_argument("--vocabfile_path", help="path of vocab file", type=str, default="./tokenizer/vocab.json")
parser.add_argument("--model_path", help="directory to save model", type=str, default="./model/")
parser.add_argument("--log_path", help="directory of log", type=str, default="./log/")

# environment parameter setting
# 環境パラメータ設定
parser.add_argument("--random_seed", help="random seed", type=int, default=42)
parser.add_argument("--num_processer", help="num of processer (cpu logit cores)", type=int, default=1)

# model parameter setting
# モデルパラメータ設定
parser.add_argument("--input_size", help="should be larger than (2*max len of password + 3), default is 32 according to max_len=12", type=int, default=32)
parser.add_argument("--embed_size", help="embedding size", type=int, default=384)
parser.add_argument("--layer_num", help="num of layers", type=int, default=12)
parser.add_argument("--head_num", help="num of multi head", type=int, default=8)

# training parameter setting
# トレーニングパラメータ設定
parser.add_argument("--epoch_num", help="num of epoch (containing early stop))", type=int, default=30)
parser.add_argument("--batch_size", help="batch_size", type=int, default=512)
parser.add_argument("--eval_step", help="eval model every n steps", type=int, default=2000)
parser.add_argument("--save_step", help="save model every n steps", type=int, default=6000)
parser.add_argument("--early_stop", help="early stop patience", type=int, default=3)

#print(parser) #
# ArgumentParser(prog='train.py', usage=None, description=None, formatter_class=<class 
#                'argparse.HelpFormatter'>, conflict_handler='error', add_help=True)



import datasets ### 方法１
from datasets import Dataset, load_from_disk ### 方法１
datasets.config.DEFAULT_MAX_BATCH_SIZE = 200 ### 方法１
'''
### 方法2
from datasets import Dataset
from transformers import AutoTokenizer
import random
import math
parser.add_argument("--model_name", type=str, required=True, help="使用するモデルの名前またはパス")
'''


args = parser.parse_args() # char_tokenizer.pyへ
#print(args) #
# Namespace(
# dataset_path='./dataset/rockyou-cleaned-Train-ready.txt', 
# vocabfile_path='./tokenizer/vocab.json', 
# model_path='./model/', 
# log_path='./log/', 
# random_seed=42, 
# num_processer=1, 
# input_size=32, 
# embed_size=384, 
# layer_num=12, 
# head_num=8, 
# epoch_num=30, 
# batch_size=512, 
# eval_step=2000, 
# save_step=6000, 
# early_stop=3)

train_dataset_path = args.dataset_path
# ./dataset/rockyou-cleaned-Train-ready.txt

vocab_file = args.vocabfile_path # ./tokenizer/vocab.json
model_output_dir = args.model_path # ./model/
log_dir = args.log_path # ./log/

random_seed = args.random_seed # 42
num_processer = args.num_processer # 1

# model params: 14260608
input_size = args.input_size # 32
embed_size = args.embed_size # 384
layer_num = args.layer_num # 12
head_num = args.head_num # 8

epoch_num = args.epoch_num # 30
batch_size = args.batch_size # 512
eval_step = args.eval_step # 2000
save_step = args.save_step # 6000
early_stop = args.early_stop # 3


### CPUのスレッド数を最大限活用（例: 4スレッド）
#torch.set_num_threads(args.num_processer)
#torch.set_num_interop_threads(max(1, args.num_processer // 2))
### 環境変数（明示的に設定）
#os.environ["OMP_NUM_THREADS"] = str(args.num_processer)
#os.environ["MKL_NUM_THREADS"] = str(args.num_processer)
import torch # 追加
import os    # 追加
import torch.profiler
os.environ["OMP_NUM_THREADS"] = "8"  # 実行コア数に応じて
torch.set_num_threads(8)
torch.set_num_interop_threads(2)
#import multiprocessing
#multiprocessing.set_start_method("spawn", force=True)




print(f'Load tokenizer.') # Load tokenizer.
tokenizer = CharTokenizer(vocab_file=vocab_file, 
                          bos_token="<BOS>",
                          eos_token="<EOS>",
                          sep_token="<SEP>",
                          unk_token="<UNK>",
                          pad_token="<PAD>",
                          )
#print(tokenizer)
# CharTokenizer(name_or_path='', vocab_size=135, model_max_length=1000000000000000019884624838656, is_fast=False, padding_side='right', truncation_side='right', special_tokens={'bos_token': '<BOS>', 'eos_token': '<EOS>', 'unk_token': '<UNK>', 'sep_token': '<SEP>', 'pad_token': '<PAD>'}, clean_up_tokenization_spaces=False, added_tokens_decoder={
#        0: AddedToken("<BOS>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#        1: AddedToken("<SEP>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#        2: AddedToken("<EOS>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#        3: AddedToken("<UNK>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#        4: AddedToken("<PAD>", rstrip=False, lstrip=False, single_word=False, normalized=False, special=True),
#}
    

print(f'Load dataset.') # ここで時間がかかる
# Generating train split: 10612251 examples [00:05, 1934906.74 examples/s]
# Map: 100%|██████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| 10612251/10612251 [16:27<00:00, 10741.68 examples/s]
data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)


'''
###train_dataset = load_dataset('text', data_files=train_dataset_path, num_proc=num_processer, split='train')
# ✅ 追加：オフライン読み込み関数
def load_local_dataset(path):
    with open(path, encoding='utf-8') as f:
        lines = [line.strip() for line in f if line.strip()]
    return Dataset.from_dict({'text': lines})
# ⬇️ 変更（load_dataset→load_local_dataset）
train_dataset = load_local_dataset(train_dataset_path)
train_dataset = train_dataset.map(lambda examples: tokenizer(examples['text'], max_len=input_size, padding=True), batched=True)
'''

### 方法１：ディスク経由で読み込む(ディスクに保存し、そこからロードする)
def load_local_dataset(path):
    with open(path, encoding='utf-8') as f:
        lines = [line.strip() for line in f if line.strip()]
    return Dataset.from_dict({'text': lines})
# ローカル読み込み
train_ds = load_local_dataset(args.dataset_path)
train_ds.save_to_disk("tmp_train_ds")
train_dataset = load_from_disk("tmp_train_ds")
# トークナイズ＋バッチ処理
train_dataset = train_dataset.map(
    lambda examples: tokenizer(
        examples['text'],
        padding=True,
        max_len=args.input_size
    ),
    batched=True,
    batch_size=200,
###    num_proc=args.num_processer   ### ✅ 並列化
)
# データ分割
split = train_dataset.train_test_split(test_size=0.125, seed=args.random_seed)
train_dataset = split['train']
eval_dataset = split['test']


'''
### 方法2：ストリーミング＆バッチ指定(シャッフルしてバッファからランダムに取り出し)
# トークナイザの読み込み
tokenizer = AutoTokenizer.from_pretrained(args.model_name)

# データセットの読み込み
with open(args.dataset_path, encoding="utf-8") as f:
    lines = [line.strip() for line in f if line.strip()]

# シャッフル
random.seed(args.random_seed)
random.shuffle(lines)

# データセットの分割
total = len(lines)
val_n = math.floor(total * 0.125)
train_lines = lines[val_n:]
eval_lines = lines[:val_n]

# Dataset オブジェクトの作成
train_dataset = Dataset.from_dict({"text": train_lines})
eval_dataset = Dataset.from_dict({"text": eval_lines})

# トークナイザの適用（バッチ処理）
def tokenize_function(examples):
    return tokenizer(examples['text'], padding='max_length', truncation=True, max_length=args.input_size)

train_dataset = train_dataset.map(tokenize_function, batched=True, batch_size=args.batch_size)
eval_dataset = eval_dataset.map(tokenize_function, batched=True, batch_size=args.batch_size)
'''






print(f'Split dataset into training set and validation set.') # データセットを訓練セットと検証セットに分割
train_dataset= train_dataset.train_test_split(test_size=0.125)
eval_dataset = train_dataset['test']
train_dataset = train_dataset['train']

print(f'Load model config.')
config = GPT2Config(
    vocab_size=tokenizer.vocab_size,
    n_positions=input_size,
    n_embd=embed_size,
    n_layer=layer_num,
    n_head=head_num,
    bos_token_id=tokenizer.bos_token_id,
    eos_token_id=tokenizer.eos_token_id,
    activation_function="gelu_new",
    resid_pdrop=0.1,
    embd_pdrop=0.1,
    attn_pdrop=0.1,
    layer_norm_epsilon=1e-5,
    initializer_range=0.02,
    scale_attn_by_inverse_layer_idx=False,
    reorder_and_upcast_attn=False,
)

model = GPT2LMHeadModel(config=config)
print(f"Num parameters: {model.num_parameters()}") # Num parameters: 21358464

#print(model)
# GPT2LMHeadModel(
#  (transformer): GPT2Model(
#    (wte): Embedding(135, 384)
#    (wpe): Embedding(32, 384)
#    (drop): Dropout(p=0.1, inplace=False)
#    (h): ModuleList(
#      (0-11): 12 x GPT2Block(
#        (ln_1): LayerNorm((384,), eps=1e-05, elementwise_affine=True)
#        (attn): GPT2Attention(
#          (c_attn): Conv1D(nf=1152, nx=384)
#          (c_proj): Conv1D(nf=384, nx=384)
#          (attn_dropout): Dropout(p=0.1, inplace=False)
#          (resid_dropout): Dropout(p=0.1, inplace=False)
#        )
#        (ln_2): LayerNorm((384,), eps=1e-05, elementwise_affine=True)
#        (mlp): GPT2MLP(
#          (c_fc): Conv1D(nf=1536, nx=384)
#          (c_proj): Conv1D(nf=384, nx=1536)
#          (act): NewGELUActivation()
#          (dropout): Dropout(p=0.1, inplace=False)
#        )
#      )
#    )
#    (ln_f): LayerNorm((384,), eps=1e-05, elementwise_affine=True)
#  )
#  (lm_head): Linear(in_features=384, out_features=135, bias=False)
#)

#print(TrainingArguments.__module__) # transformers.training_args
#import inspect
#print(inspect.signature(TrainingArguments.__init__))
#print(f'Load training config.')
training_args = TrainingArguments(
    output_dir=model_output_dir, 
    overwrite_output_dir=True, 
    num_train_epochs=epoch_num,
    per_device_train_batch_size=batch_size,
    per_device_eval_batch_size=batch_size,
    eval_steps = eval_step,
    save_steps=save_step,
    save_strategy='steps',
###    evaluation_strategy='steps',
    eval_strategy='steps', # 変更
    prediction_loss_only=True,
    logging_dir=log_dir + time.strftime("%Y%m%d-%H:%M", time.localtime()),
    seed=random_seed,
    metric_for_best_model='eval_loss',
    load_best_model_at_end=True,
    save_total_limit=1,
    no_cuda=True,  # GPUを使う場合は False。CPUのみなら True。 追加
###    dataloader_num_workers=8,  ### 実行環境の論理コア数に合わせて調整
    )

trainer = Trainer(
    model=model,
    args=training_args,
    data_collator=data_collator,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
    callbacks=[EarlyStoppingCallback(early_stopping_patience=early_stop)],
    
)


print(f'*'*30) # ******************************
print(f'Training begin.')

'''
model = torch.compile(model)  ### Trainer に渡す前に適用

def run_training():
    with torch.profiler.profile(
        activities=[torch.profiler.ProfilerActivity.CPU],
        record_shapes=True,
        with_stack=True
    ) as prof:
        trainer.train()
        print(prof.key_averages().table(sort_by="cpu_time_total", row_limit=10))


if __name__ == "__main__":
    import torch.multiprocessing
    torch.multiprocessing.set_start_method("spawn", force=True)
    run_training()
'''

trainer.train()   
trainer.save_model(model_output_dir+"last-step/")
print(f'Model saved in {model_output_dir+"last-step/"}') # Model saved in ./model/last-step/
print(f'*'*30) # ******************************
print(f'Training done.')